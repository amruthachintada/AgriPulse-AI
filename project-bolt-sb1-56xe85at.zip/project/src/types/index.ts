export type Severity = 'Low' | 'Moderate' | 'High' | 'Critical';

export interface CropAnalysisResult {
  diagnosis: string;
  confidence: number;
  severity: Severity;
  symptoms: string[];
  possible_causes: string[];
  recommended_actions: string[];
  preventive_measures: string[];
  what_not_to_do: string[];
  weather_risk: string;
  action_window: string;
  follow_up: string;
  category: string;
}

export interface Field {
  id: string;
  name: string;
  location: string;
  crop: string;
  area: string;
  crop_age: string;
  irrigation: string;
  health: number;
  created_at: string;
}

export interface AnalysisRecord {
  id: string;
  crop: string;
  image_url: string;
  diagnosis: string;
  confidence: number;
  severity: Severity;
  created_at: string;
  result: CropAnalysisResult;
}

export interface Advisory {
  id: string;
  title: string;
  category: string;
  severity: Severity;
  date: string;
  explanation: string;
  action: string;
}

export interface WeatherCurrent {
  temp: number;
  feels_like: number;
  condition: string;
  humidity: number;
  rain_prob: number;
  wind: number;
  cloud: number;
  icon: string;
  sunrise: string;
  sunset: string;
}

export interface WeatherHour {
  label: string;
  temp: number;
  rain_prob: number;
  icon: string;
}

export interface WeatherDay {
  day: string;
  high: number;
  low: number;
  rain_prob: number;
  icon: string;
}

export interface WeatherData {
  current: WeatherCurrent;
  hourly: WeatherHour[];
  daily: WeatherDay[];
  location: string;
}

export interface ActionWindow {
  label: string;
  time: string;
  rain_risk: 'Low' | 'Moderate' | 'High';
  wind: string;
  humidity: number;
  suitable: boolean;
  reason: string;
}

export type Language = 'en' | 'te' | 'hi';
