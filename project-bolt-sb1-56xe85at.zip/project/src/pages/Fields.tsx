import { useEffect, useState } from 'react';
import { Plus, MapPin, Pencil, Trash2, ScanLine, Sprout, Droplets, Ruler } from 'lucide-react';
import { AppShell } from '@/components/navigation/AppShell';
import { Modal } from '@/components/ui/Modal';
import { useToast } from '@/components/ui/Toast';
import { useApp } from '@/lib/app';
import { useRouter } from '@/lib/router';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/lib/auth';
import { demoFields, CROPS, IRRIGATION_METHODS } from '@/lib/demoData';
import type { Field } from '@/types';

export function Fields() {
  const { t, location } = useApp();
  const { navigate } = useRouter();
  const { push } = useToast();
  const { user } = useAuth();
  const [fields, setFields] = useState<Field[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Field | null>(null);
  const [form, setForm] = useState({ name: '', crop: 'Rice', area: '', crop_age: '', irrigation: 'Drip' });

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    if (supabase && user) {
      const { data, error } = await supabase.from('fields').select('*').order('created_at', { ascending: false });
      if (!error && data) {
        setFields(data as Field[]);
        setLoading(false);
        return;
      }
    }
    setFields(demoFields);
    setLoading(false);
  }

  const openNew = () => {
    setEditing(null);
    setForm({ name: '', crop: 'Rice', area: '', crop_age: '', irrigation: 'Drip' });
    setOpen(true);
  };

  const openEdit = (f: Field) => {
    setEditing(f);
    setForm({ name: f.name, crop: f.crop, area: f.area, crop_age: f.crop_age, irrigation: f.irrigation });
    setOpen(true);
  };

  const save = async () => {
    if (!form.name) {
      push('Please enter a field name.', 'error');
      return;
    }
    if (supabase && user) {
      if (editing) {
        await supabase.from('fields').update({ ...form }).eq('id', editing.id);
      } else {
        await supabase.from('fields').insert({ ...form, location, health: 80 });
      }
    } else {
      if (editing) {
        setFields((f) => f.map((x) => (x.id === editing.id ? { ...x, ...form } : x)));
      } else {
        setFields((f) => [{ ...form, id: 'local' + Date.now(), location, health: 80, created_at: new Date().toISOString() }, ...f]);
      }
    }
    push(editing ? 'Field updated.' : 'Field added.', 'success');
    setOpen(false);
    load();
  };

  const remove = async (id: string) => {
    if (supabase && user) {
      await supabase.from('fields').delete().eq('id', id);
    } else {
      setFields((f) => f.filter((x) => x.id !== id));
    }
    push('Field deleted.', 'info');
    load();
  };

  return (
    <AppShell current="/fields">
      <div className="space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{t('myFields')}</h1>
            <p className="mt-1 text-sm text-offwhite/60">Manage your farm fields and monitor crop health.</p>
          </div>
          <button onClick={openNew} className="btn-primary !px-4 !py-2.5 text-sm">
            <Plus className="h-4 w-4" /> {t('addField')}
          </button>
        </div>

        {loading ? (
          <div className="glass rounded-3xl p-8 text-center text-offwhite/60">Loading…</div>
        ) : fields.length === 0 ? (
          <EmptyState title={t('noFields')} sub={t('noFieldsSub')} action={t('addField')} onAction={openNew} />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {fields.map((f) => (
              <div key={f.id} className="glass-strong rounded-3xl p-5 shadow-glass">
                <div className="flex items-start justify-between">
                  <div className="grid h-11 w-11 place-items-center rounded-xl bg-leaf/15 ring-1 ring-leaf/30">
                    <Sprout className="h-5 w-5 text-leaf-fresh" />
                  </div>
                  <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${f.health >= 75 ? 'bg-leaf/15 text-leaf-fresh' : 'bg-warn/15 text-warn'}`}>
                    {f.health}% Healthy
                  </span>
                </div>
                <h3 className="mt-3 font-bold">{f.name}</h3>
                <div className="mt-1 flex items-center gap-1.5 text-xs text-offwhite/50">
                  <MapPin className="h-3 w-3" /> {f.location}
                </div>
                <div className="mt-4 space-y-2 text-sm">
                  <Row icon={Sprout} label="Crop" value={f.crop} />
                  <Row icon={Ruler} label="Area" value={f.area || '—'} />
                  <Row icon={Droplets} label="Irrigation" value={f.irrigation || '—'} />
                </div>
                <div className="mt-4 flex gap-2">
                  <button onClick={() => navigate('/analyze')} className="btn-primary flex-1 !py-2 text-sm">
                    <ScanLine className="h-4 w-4" /> {t('analyze')}
                  </button>
                  <button onClick={() => openEdit(f)} className="btn-secondary !px-3 !py-2">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button onClick={() => remove(f.id)} className="btn-secondary !px-3 !py-2 text-danger">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? t('editField') : t('addField')}>
        <div className="space-y-3">
          <div>
            <label className="label-eyebrow mb-1.5 block">Field name</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="My Paddy Field" className="input-field" />
          </div>
          <div>
            <label className="label-eyebrow mb-1.5 block">Crop</label>
            <select value={form.crop} onChange={(e) => setForm({ ...form, crop: e.target.value })} className="input-field">
              {CROPS.map((c) => <option key={c} value={c} className="bg-bg-forest">{c}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label-eyebrow mb-1.5 block">Area</label>
              <input value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} placeholder="2.5 acres" className="input-field" />
            </div>
            <div>
              <label className="label-eyebrow mb-1.5 block">Crop age</label>
              <input value={form.crop_age} onChange={(e) => setForm({ ...form, crop_age: e.target.value })} placeholder="45 days" className="input-field" />
            </div>
          </div>
          <div>
            <label className="label-eyebrow mb-1.5 block">Irrigation</label>
            <select value={form.irrigation} onChange={(e) => setForm({ ...form, irrigation: e.target.value })} className="input-field">
              {IRRIGATION_METHODS.map((m) => <option key={m} value={m} className="bg-bg-forest">{m}</option>)}
            </select>
          </div>
          <div className="flex gap-2 pt-2">
            <button onClick={() => setOpen(false)} className="btn-secondary flex-1">{t('cancel')}</button>
            <button onClick={save} className="btn-primary flex-1">{t('save')}</button>
          </div>
        </div>
      </Modal>
    </AppShell>
  );
}

function Row({ icon: Icon, label, value }: { icon: typeof Sprout; label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-lg bg-white/5 px-3 py-2">
      <span className="flex items-center gap-2 text-offwhite/60"><Icon className="h-3.5 w-3.5" /> {label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

export function EmptyState({ title, sub, action, onAction }: { title: string; sub: string; action?: string; onAction?: () => void }) {
  return (
    <div className="glass-strong rounded-3xl p-10 text-center">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-leaf/15 ring-1 ring-leaf/30">
        <Sprout className="h-7 w-7 text-leaf-fresh" />
      </div>
      <h3 className="mt-4 text-lg font-bold">{title}</h3>
      <p className="mt-1 text-sm text-offwhite/60">{sub}</p>
      {action && onAction && (
        <button onClick={onAction} className="btn-primary mt-5">
          <Plus className="h-4 w-4" /> {action}
        </button>
      )}
    </div>
  );
}
