import { useEffect, useState } from 'react';
import { Droplets, CloudRain, Thermometer, ShieldCheck, AlertTriangle } from 'lucide-react';
import { AppShell } from '@/components/navigation/AppShell';
import { WeatherCard, HourlyForecast } from '@/components/dashboard/WeatherCard';
import { WeatherIcon } from '@/components/ui/WeatherIcon';
import { useApp } from '@/lib/app';
import { getWeather, getActionWindow } from '@/lib/weather';
import type { WeatherData, ActionWindow } from '@/types';

export function Weather() {
  const { t, location } = useApp();
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [win, setWin] = useState<ActionWindow | null>(null);

  useEffect(() => {
    getWeather(location).then((w) => {
      setWeather(w);
      setWin(getActionWindow(w));
    });
  }, [location]);

  if (!weather || !win) {
    return (
      <AppShell current="/weather">
        <div className="glass rounded-3xl p-8 text-center text-offwhite/60">Loading weather…</div>
      </AppShell>
    );
  }

  const maxTemp = Math.max(...weather.hourly.map((h) => h.temp));
  const minTemp = Math.min(...weather.hourly.map((h) => h.temp));

  return (
    <AppShell current="/weather">
      <div className="space-y-5">
        <div>
          <div className="label-eyebrow">{t('weather')}</div>
          <h1 className="mt-1 text-2xl font-extrabold tracking-tight sm:text-3xl">{location}</h1>
        </div>

        <WeatherCard weather={weather} />
        <HourlyForecast weather={weather} />

        {/* Charts */}
        <div className="grid gap-4 lg:grid-cols-2">
          <ChartCard title="Temperature" icon={Thermometer}>
            <div className="flex h-40 items-end gap-2">
              {weather.hourly.map((h, i) => (
                <div key={i} className="flex flex-1 flex-col items-center gap-1.5">
                  <span className="text-[10px] text-offwhite/50">{h.temp}°</span>
                  <div
                    className="w-full rounded-t-lg bg-gradient-to-t from-leaf to-leaf-fresh"
                    style={{ height: `${((h.temp - minTemp) / Math.max(1, maxTemp - minTemp)) * 100 + 20}%` }}
                  />
                  <span className="text-[10px] text-offwhite/50">{h.label}</span>
                </div>
              ))}
            </div>
          </ChartCard>

          <ChartCard title="Chance of rain" icon={CloudRain}>
            <div className="flex h-40 items-end gap-2">
              {weather.hourly.map((h, i) => (
                <div key={i} className="flex flex-1 flex-col items-center gap-1.5">
                  <span className="text-[10px] text-offwhite/50">{h.rain_prob}%</span>
                  <div
                    className="w-full rounded-t-lg bg-gradient-to-t from-leaf-fresh to-leaf-sage"
                    style={{ height: `${h.rain_prob + 10}%` }}
                  />
                  <span className="text-[10px] text-offwhite/50">{h.label}</span>
                </div>
              ))}
            </div>
          </ChartCard>
        </div>

        {/* 7-day forecast */}
        <div className="glass rounded-3xl p-5">
          <div className="label-eyebrow mb-4">7-day forecast</div>
          <div className="space-y-2">
            {weather.daily.map((d, i) => (
              <div key={i} className="flex items-center gap-4 rounded-xl bg-white/5 px-4 py-3">
                <span className="w-14 text-sm font-medium">{d.day}</span>
                <WeatherIcon icon={d.icon} className="h-6 w-6" />
                <div className="flex-1">
                  <div className="h-1.5 rounded-full bg-white/10">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-leaf-fresh to-warn"
                      style={{ width: `${((d.high - 20) / 20) * 100}%` }}
                    />
                  </div>
                </div>
                <span className="text-sm text-offwhite/50">{d.low}°</span>
                <span className="text-sm font-semibold">{d.high}°</span>
                <span className="flex w-12 items-center justify-end gap-1 text-xs text-leaf-sage">
                  <CloudRain className="h-3 w-3" /> {d.rain_prob}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Is it safe to act */}
        <div className="glass-strong rounded-3xl p-5 shadow-glass">
          <div className="label-eyebrow">{t('isItSafeToAct')}</div>
          <div className="mt-4 flex items-center gap-3">
            {win.suitable ? (
              <ShieldCheck className="h-8 w-8 text-leaf-fresh" />
            ) : (
              <AlertTriangle className="h-8 w-8 text-warn" />
            )}
            <span className={`text-xl font-bold ${win.suitable ? 'text-leaf-fresh' : 'text-warn'}`}>
              {win.label}
            </span>
          </div>
          <p className="mt-2 text-sm text-offwhite/70">{win.reason}</p>
          <div className="mt-4 grid grid-cols-3 gap-3">
            <Mini label={t('rainRisk')} value={win.rain_risk} />
            <Mini label="Wind" value={win.wind} />
            <Mini label={t('fieldCondition')} value={win.suitable ? 'Workable' : 'Wet'} />
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function ChartCard({ title, icon: Icon, children }: { title: string; icon: typeof Droplets; children: React.ReactNode }) {
  return (
    <div className="glass rounded-3xl p-5">
      <div className="mb-4 flex items-center gap-2">
        <Icon className="h-5 w-5 text-leaf-fresh" />
        <h3 className="font-bold">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-white/5 px-3 py-2.5 text-center">
      <div className="text-[10px] uppercase tracking-wide text-offwhite/50">{label}</div>
      <div className="mt-0.5 text-sm font-semibold">{value}</div>
    </div>
  );
}
