import { ScanLine, Cloud, Brain, ShieldCheck, Camera, Search, CloudSun, CheckCircle2, ArrowRight } from 'lucide-react';
import { Navbar } from '@/components/navigation/Navbar';
import { useApp } from '@/lib/app';
import { useRouter } from '@/lib/router';
import { useAuth } from '@/lib/auth';

const heroImg = 'https://images.pexels.com/photos/28245340/pexels-photo-28245340.jpeg?auto=compress&cs=tinysrgb&h=900&w=700';
const fieldImg = 'https://images.pexels.com/photos/4809706/pexels-photo-4809706.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

export function Landing() {
  const { t } = useApp();
  const { navigate } = useRouter();
  const { user } = useAuth();

  const features = [
    { icon: ScanLine, title: t('aiDiagnosis'), desc: 'Upload a leaf photo and let AI identify possible crop issues.' },
    { icon: Cloud, title: t('realtimeWeather'), desc: 'Live conditions and forecast tailored to your field location.' },
    { icon: Brain, title: t('climateIntel'), desc: 'Crop and weather combined into climate-aware risk insight.' },
    { icon: ShieldCheck, title: t('actionable'), desc: 'Simple, farmer-friendly steps — not technical jargon.' },
  ];

  const steps = [
    { n: '01', icon: Camera, title: t('capture'), desc: t('captureDesc') },
    { n: '02', icon: Search, title: t('analyzeStep'), desc: t('analyzeDesc') },
    { n: '03', icon: CloudSun, title: t('understand'), desc: t('understandDesc') },
    { n: '04', icon: CheckCircle2, title: t('act'), desc: t('actDesc') },
  ];

  return (
    <div className="bg-botanical min-h-screen">
      <Navbar onNavigate={navigate} />

      {/* Hero */}
      <section className="relative px-4 pt-28 pb-16 sm:pt-36 sm:pb-24">
        <div className="mx-auto grid max-w-6xl items-center gap-10 lg:grid-cols-2">
          <div className="animate-slide-up">
            <span className="label-eyebrow inline-flex items-center gap-2 rounded-full glass px-3 py-1.5">
              <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-leaf-fresh" />
              {t('tagline')}
            </span>
            <h1 className="mt-5 whitespace-pre-line text-4xl font-extrabold leading-[1.1] tracking-tight text-balance sm:text-5xl lg:text-6xl">
              {t('heroTitle')}
            </h1>
            <p className="mt-5 max-w-md text-base text-offwhite/70 sm:text-lg">{t('heroSub')}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button onClick={() => navigate(user ? '/analyze' : '/login')} className="btn-primary">
                <ScanLine className="h-5 w-5" />
                {t('analyzeMyCrop')}
              </button>
              <button onClick={() => navigate('/weather')} className="btn-secondary">
                <Cloud className="h-5 w-5" />
                {t('checkWeather')}
              </button>
            </div>
          </div>

          {/* Hero visual */}
          <div className="relative animate-fade-in">
            <div className="relative mx-auto max-w-sm">
              <div className="overflow-hidden rounded-3xl glass-strong p-2 shadow-glass">
                <img src={heroImg} alt="Close-up green leaf" className="h-[420px] w-full rounded-2xl object-cover" />
              </div>
              {/* AI scanning overlay */}
              <div className="pointer-events-none absolute inset-2 overflow-hidden rounded-2xl">
                <div className="absolute inset-0 bg-gradient-to-b from-leaf/5 via-transparent to-bg-deep/40" />
                <div className="absolute left-0 right-0 h-0.5 bg-leaf-fresh/70 shadow-glow animate-scan-line" />
                <div className="absolute left-6 top-8 flex items-center gap-2 rounded-full glass px-3 py-1.5 text-xs">
                  <span className="h-2 w-2 animate-pulse-soft rounded-full bg-leaf-fresh" /> Scanning…
                </div>
                <div className="absolute right-6 top-20 rounded-full glass px-2.5 py-1 text-[10px] text-leaf-fresh">
                  ● Leaf node
                </div>
                <div className="absolute bottom-24 left-8 rounded-full glass px-2.5 py-1 text-[10px] text-warn">
                  ⚠ Symptom marker
                </div>
                <div className="absolute bottom-8 right-6 rounded-xl glass-strong px-3 py-2 text-xs">
                  <div className="font-bold text-leaf-fresh">82% Healthy</div>
                  <div className="text-offwhite/60">Crop health</div>
                </div>
              </div>
              {/* floating weather chip */}
              <div className="absolute -left-4 top-1/2 hidden animate-float rounded-2xl glass-strong p-3 shadow-glass sm:block">
                <div className="flex items-center gap-2">
                  <CloudSun className="h-6 w-6 text-leaf-sage" />
                  <div>
                    <div className="text-lg font-bold">32°</div>
                    <div className="text-[10px] text-offwhite/60">Partly Cloudy</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-4 py-12">
        <div className="mx-auto grid max-w-6xl gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div key={f.title} className="glass rounded-2xl p-5 transition hover:bg-white/[0.07] hover:shadow-glow-sm">
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-leaf/15 ring-1 ring-leaf/30">
                <f.icon className="h-5 w-5 text-leaf-fresh" />
              </div>
              <h3 className="mt-4 font-bold">{f.title}</h3>
              <p className="mt-1.5 text-sm text-offwhite/60">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="px-4 py-16">
        <div className="mx-auto max-w-6xl">
          <div className="mb-10 text-center">
            <span className="label-eyebrow">How it works</span>
            <h2 className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl">From photo to action in four steps</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {steps.map((s, i) => (
              <div key={s.n} className="relative">
                <div className="glass rounded-2xl p-6">
                  <div className="flex items-center justify-between">
                    <span className="text-3xl font-extrabold text-leaf/40">{s.n}</span>
                    <s.icon className="h-6 w-6 text-leaf-fresh" />
                  </div>
                  <h3 className="mt-4 font-bold">{s.title}</h3>
                  <p className="mt-1.5 text-sm text-offwhite/60">{s.desc}</p>
                </div>
                {i < steps.length - 1 && (
                  <ArrowRight className="absolute -right-3 top-1/2 hidden h-5 w-5 -translate-y-1/2 text-leaf/40 lg:block" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA band */}
      <section className="px-4 py-16">
        <div className="relative mx-auto max-w-6xl overflow-hidden rounded-3xl glass-strong p-8 sm:p-12">
          <img src={fieldImg} alt="Green field" className="absolute inset-0 h-full w-full object-cover opacity-20" />
          <div className="relative">
            <h2 className="max-w-lg text-3xl font-extrabold tracking-tight text-balance sm:text-4xl">
              Act before it’s too late.
            </h2>
            <p className="mt-3 max-w-md text-offwhite/70">
              Start with a single photo. AgriPulse AI turns it into clear, weather-aware guidance you can trust.
            </p>
            <button onClick={() => navigate(user ? '/analyze' : '/login')} className="btn-primary mt-6">
              <ScanLine className="h-5 w-5" />
              {t('analyzeMyCrop')}
            </button>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/8 px-4 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 text-sm text-offwhite/50 sm:flex-row">
          <p>AgriPulse AI — {t('tagline')}</p>
          <p>AI guidance is advisory. Always follow product labels and local recommendations.</p>
        </div>
      </footer>
    </div>
  );
}
