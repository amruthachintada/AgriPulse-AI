import { useState } from 'react';
import { Mail, Lock, User as UserIcon, ArrowLeft, Eye, EyeOff } from 'lucide-react';
import { LogoWordmark } from '@/components/ui/Logo';
import { useApp } from '@/lib/app';
import { useRouter } from '@/lib/router';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/components/ui/Toast';

type Mode = 'login' | 'signup' | 'forgot';

export function Auth({ mode }: { mode: Mode }) {
  const { t } = useApp();
  const { navigate } = useRouter();
  const { signIn, signUp } = useAuth();
  const { push } = useToast();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (mode === 'signup' && password !== confirm) {
      setError('Passwords do not match.');
      return;
    }
    if (mode === 'forgot') {
      push('If that email exists, a reset link has been sent.', 'info');
      navigate('/login');
      return;
    }
    setLoading(true);
    const res = mode === 'login' ? await signIn(email, password) : await signUp(name, email, password);
    setLoading(false);
    if (res.error) {
      setError(res.error);
      return;
    }
    push(mode === 'login' ? 'Welcome back!' : 'Account created!', 'success');
    navigate('/dashboard');
  };

  return (
    <div className="bg-botanical flex min-h-screen flex-col">
      <div className="flex items-center justify-between px-4 pt-6">
        <button onClick={() => navigate('/')} className="flex items-center">
          <LogoWordmark compact />
        </button>
        <button onClick={() => navigate('/')} className="btn-ghost">
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
      </div>

      <div className="flex flex-1 items-center justify-center px-4 py-10">
        <div className="w-full max-w-md">
          <div className="glass-strong rounded-3xl p-6 shadow-glass sm:p-8 animate-slide-up">
            <h1 className="text-2xl font-extrabold tracking-tight">
              {mode === 'login' ? t('login') : mode === 'signup' ? t('signup') : t('forgotPassword')}
            </h1>
            <p className="mt-1 text-sm text-offwhite/60">
              {mode === 'login'
                ? 'Welcome back to your fields.'
                : mode === 'signup'
                ? 'Start monitoring your crop health.'
                : "We'll help you get back in."}
            </p>

            <form onSubmit={submit} className="mt-6 space-y-4">
              {mode === 'signup' && (
                <div>
                  <label className="label-eyebrow mb-1.5 block">{t('name')}</label>
                  <div className="relative">
                    <UserIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-offwhite/40" />
                    <input
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="input-field pl-10"
                      placeholder="Farmer Name"
                    />
                  </div>
                </div>
              )}
              <div>
                <label className="label-eyebrow mb-1.5 block">{t('email')}</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-offwhite/40" />
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="input-field pl-10"
                    placeholder="you@farm.com"
                  />
                </div>
              </div>
              {mode !== 'forgot' && (
                <div>
                  <label className="label-eyebrow mb-1.5 block">{t('password')}</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-offwhite/40" />
                    <input
                      required
                      type={show ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="input-field pl-10 pr-10"
                      placeholder="••••••••"
                    />
                    <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-offwhite/40 hover:text-offwhite">
                      {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
              )}
              {mode === 'signup' && (
                <div>
                  <label className="label-eyebrow mb-1.5 block">{t('confirmPassword')}</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-offwhite/40" />
                    <input
                      required
                      type={show ? 'text' : 'password'}
                      value={confirm}
                      onChange={(e) => setConfirm(e.target.value)}
                      className="input-field pl-10"
                      placeholder="••••••••"
                    />
                  </div>
                </div>
              )}

              {error && (
                <div className="rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger ring-1 ring-danger/30">
                  {error}
                </div>
              )}

              {mode === 'login' && (
                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 text-offwhite/60">
                    <input type="checkbox" className="accent-leaf-fresh" /> {t('rememberMe')}
                  </label>
                  <button type="button" onClick={() => navigate('/forgot')} className="text-leaf-fresh hover:underline">
                    {t('forgotPassword')}
                  </button>
                </div>
              )}

              <button type="submit" disabled={loading} className="btn-primary w-full">
                {loading ? 'Please wait…' : mode === 'login' ? t('login') : mode === 'signup' ? t('signup') : 'Send reset link'}
              </button>
            </form>

            <div className="mt-5 text-center text-sm text-offwhite/60">
              {mode === 'login' ? (
                <>
                  {t('dontHaveAccount')}{' '}
                  <button onClick={() => navigate('/signup')} className="text-leaf-fresh hover:underline">
                    {t('signup')}
                  </button>
                </>
              ) : mode === 'signup' ? (
                <>
                  {t('alreadyHaveAccount')}{' '}
                  <button onClick={() => navigate('/login')} className="text-leaf-fresh hover:underline">
                    {t('login')}
                  </button>
                </>
              ) : (
                <button onClick={() => navigate('/login')} className="text-leaf-fresh hover:underline">
                  {t('login')}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
