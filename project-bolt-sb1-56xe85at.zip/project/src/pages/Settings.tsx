import { Globe, User, MapPin, LogOut, Info } from 'lucide-react';
import { AppShell } from '@/components/navigation/AppShell';
import { useApp } from '@/lib/app';
import { useAuth } from '@/lib/auth';
import { useRouter } from '@/lib/router';
import type { Language } from '@/types';

export function Settings() {
  const { t, lang, setLang, location, setLocation } = useApp();
  const { user, signOut } = useAuth();
  const { navigate } = useRouter();

  const langs: { code: Language; label: string }[] = [
    { code: 'en', label: 'English' },
    { code: 'te', label: 'తెలుగు' },
    { code: 'hi', label: 'हिन्दी' },
  ];

  return (
    <AppShell current="/settings">
      <div className="space-y-5">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{t('settings')}</h1>
        </div>

        {/* Profile */}
        <div className="glass-strong rounded-3xl p-5 shadow-glass">
          <div className="label-eyebrow">Profile</div>
          <div className="mt-4 flex items-center gap-4">
            <div className="grid h-14 w-14 place-items-center rounded-2xl bg-leaf/15 ring-1 ring-leaf/30">
              <User className="h-6 w-6 text-leaf-fresh" />
            </div>
            <div>
              <div className="font-bold">{(user?.user_metadata?.full_name as string) || 'Farmer'}</div>
              <div className="text-sm text-offwhite/60">{user?.email || 'demo@agripulse.ai'}</div>
            </div>
          </div>
        </div>

        {/* Language */}
        <div className="glass-strong rounded-3xl p-5 shadow-glass">
          <div className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-leaf-fresh" />
            <div className="label-eyebrow">{t('language')}</div>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-3">
            {langs.map((l) => (
              <button
                key={l.code}
                onClick={() => setLang(l.code)}
                className={`rounded-xl py-3 text-sm font-medium transition ${
                  lang === l.code ? 'bg-leaf-fresh text-bg-deep shadow-glow-sm' : 'glass text-offwhite/70 hover:bg-white/10'
                }`}
              >
                {l.label}
              </button>
            ))}
          </div>
        </div>

        {/* Location */}
        <div className="glass-strong rounded-3xl p-5 shadow-glass">
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-leaf-fresh" />
            <div className="label-eyebrow">{t('location')}</div>
          </div>
          <input
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="input-field mt-3"
            placeholder="City, State"
          />
          <p className="mt-2 text-xs text-offwhite/50">This is used for weather and advisories.</p>
        </div>

        {/* About */}
        <div className="glass rounded-3xl p-5">
          <div className="flex items-center gap-2">
            <Info className="h-5 w-5 text-leaf-sage" />
            <div className="label-eyebrow">About</div>
          </div>
          <p className="mt-3 text-sm text-offwhite/70">
            AgriPulse AI provides advisory guidance only. AI results are not a guaranteed diagnosis. For chemical treatments, always follow the product label and local agricultural recommendations. For serious crop problems, consult a qualified agronomist.
          </p>
        </div>

        <button
          onClick={() => { signOut(); navigate('/'); }}
          className="btn-secondary w-full text-danger"
        >
          <LogOut className="h-4 w-4" /> {t('logout')}
        </button>
      </div>
    </AppShell>
  );
}
