import { useEffect, useState } from 'react';
import { ScanLine, Cloud, MapPinned, Bell, MapPin, TrendingUp, ArrowRight } from 'lucide-react';
import { AppShell } from '@/components/navigation/AppShell';
import { WeatherCard, HourlyForecast } from '@/components/dashboard/WeatherCard';
import { CropHealthCard } from '@/components/dashboard/CropHealthCard';
import { useApp } from '@/lib/app';
import { useRouter } from '@/lib/router';
import { useAuth } from '@/lib/auth';
import { getWeather } from '@/lib/weather';
import { demoAdvisories, demoFields } from '@/lib/demoData';
import type { WeatherData } from '@/types';

export function Dashboard() {
  const { t, location } = useApp();
  const { navigate } = useRouter();
  const { user } = useAuth();
  const [weather, setWeather] = useState<WeatherData | null>(null);

  useEffect(() => {
    getWeather(location).then(setWeather);
  }, [location]);

  const quickActions = [
    { icon: ScanLine, label: t('analyzeACrop'), path: '/analyze', primary: true },
    { icon: Cloud, label: t('checkWeather'), path: '/weather' },
    { icon: MapPinned, label: t('myFields'), path: '/fields' },
    { icon: Bell, label: t('viewAdvisories'), path: '/advisories' },
  ];

  const name = (user?.user_metadata?.full_name as string) || 'Farmer';
  const topAdvisory = demoAdvisories[0];

  return (
    <AppShell current="/dashboard">
      <div className="space-y-5">
        {/* Greeting */}
        <div className="animate-slide-up">
          <div className="flex items-center gap-2 text-sm text-leaf-sage">
            <MapPin className="h-4 w-4" /> {location}
          </div>
          <h1 className="mt-1 text-2xl font-extrabold tracking-tight sm:text-3xl">
            {t('goodMorning')}, {name}
          </h1>
        </div>

        {/* Quick actions */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {quickActions.map((a) => (
            <button
              key={a.path}
              onClick={() => navigate(a.path)}
              className={`flex flex-col items-start gap-3 rounded-2xl p-4 text-left transition active:scale-[0.98] ${
                a.primary
                  ? 'bg-leaf-fresh text-bg-deep shadow-glow hover:bg-leaf'
                  : 'glass hover:bg-white/[0.07]'
              }`}
            >
              <a.icon className={`h-6 w-6 ${a.primary ? '' : 'text-leaf-fresh'}`} />
              <span className="text-sm font-semibold leading-tight">{a.label}</span>
            </button>
          ))}
        </div>

        {/* Today's field grid */}
        <div className="grid gap-4 lg:grid-cols-2">
          {weather ? <WeatherCard weather={weather} /> : <div className="glass rounded-3xl p-5" />}
          <CropHealthCard health={demoFields[0].health} />
        </div>

        {weather && <HourlyForecast weather={weather} />}

        {/* AI insight + recent */}
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="glass-strong rounded-3xl p-5">
            <div className="label-eyebrow">AI weather insight</div>
            <p className="mt-3 text-sm leading-relaxed text-offwhite/80">
              {topAdvisory.explanation}
            </p>
            <div className="mt-4 flex items-center gap-2 rounded-xl bg-warn/10 px-3 py-2 text-sm text-warn ring-1 ring-warn/30">
              <TrendingUp className="h-4 w-4" /> {topAdvisory.action}
            </div>
          </div>

          <div className="glass rounded-3xl p-5">
            <div className="flex items-center justify-between">
              <div className="label-eyebrow">Recent fields</div>
              <button onClick={() => navigate('/fields')} className="text-xs text-leaf-fresh hover:underline">
                View all
              </button>
            </div>
            <div className="mt-3 space-y-2">
              {demoFields.map((f) => (
                <button
                  key={f.id}
                  onClick={() => navigate('/fields')}
                  className="flex w-full items-center justify-between rounded-xl bg-white/5 px-4 py-3 text-left hover:bg-white/[0.08]"
                >
                  <div>
                    <div className="font-semibold">{f.name}</div>
                    <div className="text-xs text-offwhite/50">{f.crop} · {f.area}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`text-sm font-bold ${f.health >= 75 ? 'text-leaf-fresh' : 'text-warn'}`}>
                      {f.health}%
                    </span>
                    <ArrowRight className="h-4 w-4 text-offwhite/40" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
