import { useEffect, useState } from 'react';
import { ScanLine, Calendar, ChevronRight } from 'lucide-react';
import { AppShell } from '@/components/navigation/AppShell';
import { SeverityBadge } from '@/components/ui/ConfidenceScore';
import { useApp } from '@/lib/app';
import { useRouter } from '@/lib/router';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/lib/auth';
import { demoHistory } from '@/lib/demoData';
import { EmptyState } from './Fields';
import type { AnalysisRecord } from '@/types';

export function History() {
  const { t } = useApp();
  const { navigate } = useRouter();
  const { user } = useAuth();
  const [items, setItems] = useState<AnalysisRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    if (supabase && user) {
      const { data } = await supabase.from('crop_analyses').select('*').order('created_at', { ascending: false });
      if (data && data.length) {
        setItems(data as AnalysisRecord[]);
        setLoading(false);
        return;
      }
    }
    setItems(demoHistory);
    setLoading(false);
  }

  return (
    <AppShell current="/history">
      <div className="space-y-5">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{t('cropHistory')}</h1>
          <p className="mt-1 text-sm text-offwhite/60">Review your past crop analyses and track health over time.</p>
        </div>

        {loading ? (
          <div className="glass rounded-3xl p-8 text-center text-offwhite/60">Loading…</div>
        ) : items.length === 0 ? (
          <EmptyState title={t('noAnalyses')} sub={t('noAnalysesSub')} action={t('analyzeMyCrop')} onAction={() => navigate('/analyze')} />
        ) : (
          <>
            {/* Health timeline */}
            <div className="glass-strong rounded-3xl p-5">
              <div className="label-eyebrow mb-4">Health timeline</div>
              <div className="flex items-end gap-2">
                {items.map((h, i) => (
                  <div key={h.id} className="flex flex-1 flex-col items-center gap-2">
                    <div
                      className={`w-full rounded-t-lg ${h.confidence >= 75 ? 'bg-leaf-fresh' : h.confidence >= 60 ? 'bg-warn' : 'bg-danger'}`}
                      style={{ height: `${h.confidence}px` }}
                    />
                    <span className="text-[10px] text-offwhite/50">{i + 1}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* List */}
            <div className="space-y-3">
              {items.map((h) => (
                <button
                  key={h.id}
                  onClick={() => navigate('/analyze')}
                  className="glass flex w-full items-center gap-4 rounded-2xl p-4 text-left hover:bg-white/[0.07]"
                >
                  <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-leaf/15 ring-1 ring-leaf/30">
                    <ScanLine className="h-5 w-5 text-leaf-fresh" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{h.diagnosis}</span>
                      <span className="rounded-full bg-white/5 px-2 py-0.5 text-xs text-offwhite/60">{h.crop}</span>
                    </div>
                    <div className="mt-1 flex items-center gap-3 text-xs text-offwhite/50">
                      <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {new Date(h.created_at).toLocaleDateString()}</span>
                      <span>AI confidence {h.confidence}%</span>
                    </div>
                  </div>
                  <SeverityBadge severity={h.severity} />
                  <ChevronRight className="h-5 w-5 text-offwhite/40" />
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </AppShell>
  );
}
