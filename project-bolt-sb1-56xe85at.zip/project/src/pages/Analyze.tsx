import { useEffect, useState } from 'react';
import { ScanLine, MapPin, ChevronDown, Sprout, Info } from 'lucide-react';
import { AppShell } from '@/components/navigation/AppShell';
import { UploadBox } from '@/components/analysis/UploadBox';
import { AIScanner } from '@/components/analysis/AIScanner';
import { ResultView } from '@/components/analysis/ResultView';
import { useApp } from '@/lib/app';
import { useToast } from '@/components/ui/Toast';
import { analyzeCropMock } from '@/lib/mockAI';
import { getWeather, getActionWindow } from '@/lib/weather';
import { CROPS, SOIL_TYPES, IRRIGATION_METHODS } from '@/lib/demoData';
import type { CropAnalysisResult, WeatherData, ActionWindow } from '@/types';

type Stage = 'input' | 'scanning' | 'result';

export function Analyze() {
  const { t, location, setLocation } = useApp();
  const { push } = useToast();

  const [stage, setStage] = useState<Stage>('input');
  const [crop, setCrop] = useState('Rice');
  const [customCrop, setCustomCrop] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [manualLoc, setManualLoc] = useState({ village: '', city: '', state: '', country: '' });
  const [useManual, setUseManual] = useState(false);
  const [fieldInfo, setFieldInfo] = useState({ age: '', soil: '', irrigation: '', symptoms: '', started: '', treatment: '' });
  const [result, setResult] = useState<CropAnalysisResult | null>(null);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [window, setWindow] = useState<ActionWindow | null>(null);

  useEffect(() => {
    getWeather(location).then(setWeather);
  }, [location]);

  const detectLocation = () => {
    if (!navigator.geolocation) {
      push('Geolocation not supported. Please enter your location manually.', 'info');
      setUseManual(true);
      return;
    }
    push('Detecting your location…', 'info');
    navigator.geolocation.getCurrentPosition(
      () => {
        setLocation('Vijayawada, Andhra Pradesh');
        push('Location detected.', 'success');
      },
      () => {
        push('We couldn\'t access your location. Please enter it manually.', 'error');
        setUseManual(true);
      },
      { timeout: 8000 }
    );
  };

  const handleUpload = (_file: File, dataUrl: string) => {
    setImage(dataUrl);
  };

  const analyze = async () => {
    if (!image) {
      push('Please upload a crop image first.', 'error');
      return;
    }
    const finalCrop = crop === 'Other' && customCrop ? customCrop : crop;
    setStage('scanning');
    const [res, w] = await Promise.all([
      analyzeCropMock(finalCrop, image),
      getWeather(location),
    ]);
    setWeather(w);
    setWindow(getActionWindow(w));
    setResult(res);
    setTimeout(() => setStage('result'), 5200);
  };

  const finalCrop = crop === 'Other' && customCrop ? customCrop : crop;

  return (
    <AppShell current="/analyze">
      <div className="space-y-5">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">Analyze Your Crop</h1>
          <p className="mt-1 text-sm text-offwhite/60">
            Upload a clear photo of the affected leaf or crop and let AI identify possible problems.
          </p>
        </div>

        {stage === 'input' && (
          <div className="space-y-5 animate-fade-in">
            {/* Step 1: crop */}
            <div className="glass-strong rounded-3xl p-5 shadow-glass">
              <div className="flex items-center gap-2">
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-leaf/15 text-sm font-bold text-leaf-fresh">1</span>
                <h2 className="font-bold">{t('selectCrop')}</h2>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {CROPS.map((c) => (
                  <button
                    key={c}
                    onClick={() => setCrop(c)}
                    className={`rounded-xl px-4 py-2 text-sm font-medium transition ${
                      crop === c
                        ? 'bg-leaf-fresh text-bg-deep shadow-glow-sm'
                        : 'glass text-offwhite/70 hover:bg-white/10'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
              {crop === 'Other' && (
                <input
                  value={customCrop}
                  onChange={(e) => setCustomCrop(e.target.value)}
                  placeholder="Enter crop name"
                  className="input-field mt-3"
                />
              )}
            </div>

            {/* Step 2: location */}
            <div className="glass-strong rounded-3xl p-5 shadow-glass">
              <div className="flex items-center gap-2">
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-leaf/15 text-sm font-bold text-leaf-fresh">2</span>
                <h2 className="font-bold">{t('location')}</h2>
              </div>
              {!useManual ? (
                <div className="mt-4">
                  <div className="flex items-center gap-2 rounded-xl bg-white/5 px-4 py-3 text-sm text-offwhite/70">
                    <MapPin className="h-4 w-4 text-leaf-fresh" /> {location}
                  </div>
                  <div className="mt-3 flex gap-2">
                    <button onClick={detectLocation} className="btn-secondary !py-2 text-sm">
                      <MapPin className="h-4 w-4" /> {t('useMyLocation')}
                    </button>
                    <button onClick={() => setUseManual(true)} className="btn-ghost text-sm">
                      Enter manually
                    </button>
                  </div>
                </div>
              ) : (
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <input value={manualLoc.village} onChange={(e) => setManualLoc({ ...manualLoc, village: e.target.value })} placeholder={t('village')} className="input-field" />
                  <input value={manualLoc.city} onChange={(e) => setManualLoc({ ...manualLoc, city: e.target.value })} placeholder={t('city')} className="input-field" />
                  <input value={manualLoc.state} onChange={(e) => setManualLoc({ ...manualLoc, state: e.target.value })} placeholder={t('state')} className="input-field" />
                  <input value={manualLoc.country} onChange={(e) => setManualLoc({ ...manualLoc, country: e.target.value })} placeholder={t('country')} className="input-field" />
                  <button
                    onClick={() => {
                      const parts = [manualLoc.village, manualLoc.city, manualLoc.state, manualLoc.country].filter(Boolean);
                      if (parts.length) setLocation(parts.join(', '));
                      setUseManual(false);
                      push('Location updated.', 'success');
                    }}
                    className="btn-primary col-span-full !py-2 text-sm sm:col-span-2"
                  >
                    Save location
                  </button>
                </div>
              )}
            </div>

            {/* Step 3: image */}
            <div className="glass-strong rounded-3xl p-5 shadow-glass">
              <div className="flex items-center gap-2">
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-leaf/15 text-sm font-bold text-leaf-fresh">3</span>
                <h2 className="font-bold">{t('scanYourPlant')}</h2>
              </div>
              <p className="mt-1 text-sm text-offwhite/60">{t('uploadHint')}</p>
              <div className="mt-4">
                <UploadBox onUpload={handleUpload} preview={image} onRemove={() => setImage(null)} />
              </div>
            </div>

            {/* Step 4: optional field info */}
            <details className="glass rounded-3xl p-5 group">
              <summary className="flex cursor-pointer items-center justify-between font-bold">
                <span className="flex items-center gap-2">
                  <Info className="h-4 w-4 text-leaf-sage" /> {t('optional')} field information
                </span>
                <ChevronDown className="h-5 w-5 transition group-open:rotate-180" />
              </summary>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <Field label={t('cropAge')} value={fieldInfo.age} onChange={(v) => setFieldInfo({ ...fieldInfo, age: v })} placeholder="e.g. 45 days" />
                <SelectField label={t('soilType')} value={fieldInfo.soil} onChange={(v) => setFieldInfo({ ...fieldInfo, soil: v })} options={SOIL_TYPES} />
                <SelectField label={t('irrigation')} value={fieldInfo.irrigation} onChange={(v) => setFieldInfo({ ...fieldInfo, irrigation: v })} options={IRRIGATION_METHODS} />
                <Field label={t('whenStarted')} value={fieldInfo.started} onChange={(v) => setFieldInfo({ ...fieldInfo, started: v })} placeholder="e.g. 3 days ago" />
                <Field label={t('symptomsObserved')} value={fieldInfo.symptoms} onChange={(v) => setFieldInfo({ ...fieldInfo, symptoms: v })} placeholder="Describe what you see" />
                <Field label={t('previousTreatment')} value={fieldInfo.treatment} onChange={(v) => setFieldInfo({ ...fieldInfo, treatment: v })} placeholder="Any treatment applied" />
              </div>
            </details>

            <button onClick={analyze} className="btn-primary w-full text-base">
              <ScanLine className="h-5 w-5" /> {t('analyzeMyCrop')}
            </button>
          </div>
        )}

        {stage === 'scanning' && image && (
          <AIScanner image={image} onDone={() => setStage('result')} />
        )}

        {stage === 'result' && result && weather && window && image && (
          <div className="space-y-4">
            <button onClick={() => { setStage('input'); setImage(null); setResult(null); }} className="btn-secondary">
              <Sprout className="h-4 w-4" /> Analyze another crop
            </button>
            <ResultView result={result} image={image} weather={weather} window={window} crop={finalCrop} />
          </div>
        )}
      </div>
    </AppShell>
  );
}

function Field({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div>
      <label className="label-eyebrow mb-1.5 block">{label}</label>
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="input-field" />
    </div>
  );
}

function SelectField({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <div>
      <label className="label-eyebrow mb-1.5 block">{label}</label>
      <select value={value} onChange={(e) => onChange(e.target.value)} className="input-field">
        <option value="">Select…</option>
        {options.map((o) => (
          <option key={o} value={o} className="bg-bg-forest">{o}</option>
        ))}
      </select>
    </div>
  );
}
