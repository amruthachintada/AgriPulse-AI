import { useEffect, useState } from 'react';
import { Bell, CloudRain, Leaf, Droplets, Bug, ShieldAlert, AlertTriangle } from 'lucide-react';
import { AppShell } from '@/components/navigation/AppShell';
import { SeverityBadge } from '@/components/ui/ConfidenceScore';
import { useApp } from '@/lib/app';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/lib/auth';
import { demoAdvisories } from '@/lib/demoData';
import { EmptyState } from './Fields';
import type { Advisory } from '@/types';

const categoryIcon: Record<string, typeof Bell> = {
  Weather: CloudRain,
  'Crop Health': Leaf,
  Irrigation: Droplets,
  'Pest Risk': Bug,
  Prevention: ShieldAlert,
  Alerts: AlertTriangle,
};

export function Advisories() {
  const { t } = useApp();
  const { user } = useAuth();
  const [items, setItems] = useState<Advisory[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');

  const categories = ['All', 'Weather', 'Crop Health', 'Irrigation', 'Pest Risk', 'Prevention', 'Alerts'];

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    if (supabase && user) {
      const { data } = await supabase.from('advisories').select('*').order('created_at', { ascending: false });
      if (data && data.length) {
        setItems(data as Advisory[]);
        setLoading(false);
        return;
      }
    }
    setItems(demoAdvisories);
    setLoading(false);
  }

  const filtered = filter === 'All' ? items : items.filter((a) => a.category === filter);

  return (
    <AppShell current="/advisories">
      <div className="space-y-5">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{t('advisories')}</h1>
          <p className="mt-1 text-sm text-offwhite/60">Climate-aware guidance and alerts for your fields.</p>
        </div>

        {/* Category filter */}
        <div className="no-scrollbar flex gap-2 overflow-x-auto">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className={`shrink-0 rounded-xl px-4 py-2 text-sm font-medium transition ${
                filter === c ? 'bg-leaf-fresh text-bg-deep' : 'glass text-offwhite/70 hover:bg-white/10'
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="glass rounded-3xl p-8 text-center text-offwhite/60">Loading…</div>
        ) : filtered.length === 0 ? (
          <EmptyState title={t('noAdvisories')} sub="No advisories in this category right now." />
        ) : (
          <div className="space-y-3">
            {filtered.map((a) => {
              const Icon = categoryIcon[a.category] ?? Bell;
              return (
                <div key={a.id} className="glass-strong rounded-3xl p-5 shadow-glass">
                  <div className="flex items-start gap-4">
                    <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-leaf/15 ring-1 ring-leaf/30">
                      <Icon className="h-5 w-5 text-leaf-fresh" />
                    </div>
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-bold">{a.title}</h3>
                        <span className="rounded-full bg-white/5 px-2 py-0.5 text-xs text-offwhite/60">{a.category}</span>
                      </div>
                      <p className="mt-1.5 text-sm text-offwhite/70">{a.explanation}</p>
                      <div className="mt-3 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <SeverityBadge severity={a.severity} />
                          <span className="text-xs text-offwhite/50">{new Date(a.date).toLocaleDateString()}</span>
                        </div>
                      </div>
                      <div className="mt-3 rounded-xl bg-leaf/10 px-4 py-2.5 text-sm text-leaf-fresh ring-1 ring-leaf/20">
                        {a.action}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </AppShell>
  );
}
