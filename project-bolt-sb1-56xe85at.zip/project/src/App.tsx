import { useEffect } from 'react';
import { RouterProvider, useRouter } from '@/lib/router';
import { AuthProvider, useAuth } from '@/lib/auth';
import { AppProvider } from '@/lib/app';
import { ToastProvider } from '@/components/ui/Toast';
import { Landing } from '@/pages/Landing';
import { Auth } from '@/pages/Auth';
import { Dashboard } from '@/pages/Dashboard';
import { Analyze } from '@/pages/Analyze';
import { Weather } from '@/pages/Weather';
import { Fields } from '@/pages/Fields';
import { History } from '@/pages/History';
import { Advisories } from '@/pages/Advisories';
import { Settings } from '@/pages/Settings';

function Routes() {
  const { path } = useRouter();
  const { user, loading } = useAuth();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [path]);

  if (loading) {
    return (
      <div className="bg-botanical grid min-h-screen place-items-center">
        <div className="text-leaf-sage animate-pulse-soft">Loading AgriPulse AI…</div>
      </div>
    );
  }

  // Public routes
  if (path === '/' || path === '') return <Landing />;
  if (path === '/login') return <Auth mode="login" />;
  if (path === '/signup') return <Auth mode="signup" />;
  if (path === '/forgot') return <Auth mode="forgot" />;

  // Protected routes — redirect to login if not authenticated
  const protectedRoutes: Record<string, React.ReactNode> = {
    '/dashboard': <Dashboard />,
    '/analyze': <Analyze />,
    '/weather': <Weather />,
    '/fields': <Fields />,
    '/history': <History />,
    '/advisories': <Advisories />,
    '/settings': <Settings />,
  };

  if (protectedRoutes[path]) {
    if (!user) {
      window.history.replaceState({}, '', '/login');
      return <Auth mode="login" />;
    }
    return <>{protectedRoutes[path]}</>;
  }

  // Fallback
  return <Landing />;
}

export default function App() {
  return (
    <RouterProvider>
      <AuthProvider>
        <AppProvider>
          <ToastProvider>
            <Routes />
          </ToastProvider>
        </AppProvider>
      </AuthProvider>
    </RouterProvider>
  );
}
