import { Droplets, Wind, Cloud, CloudRain, Sunrise, Sunset } from 'lucide-react';
import { WeatherIcon } from '@/components/ui/WeatherIcon';
import type { WeatherData } from '@/types';

export function WeatherCard({ weather }: { weather: WeatherData }) {
  const c = weather.current;
  return (
    <div className="glass-strong rounded-3xl p-5 shadow-glass">
      <div className="flex items-start justify-between">
        <div>
          <div className="label-eyebrow">Weather now</div>
          <div className="mt-1 flex items-end gap-2">
            <span className="text-5xl font-extrabold tracking-tight">{c.temp}°</span>
            <span className="mb-1.5 text-sm text-offwhite/60">{c.condition}</span>
          </div>
          <div className="text-xs text-offwhite/50">Feels like {c.feels_like}°</div>
        </div>
        <WeatherIcon icon={c.icon} className="h-12 w-12" />
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat icon={Droplets} label="Humidity" value={`${c.humidity}%`} />
        <Stat icon={CloudRain} label="Rain" value={`${c.rain_prob}%`} />
        <Stat icon={Wind} label="Wind" value={`${c.wind} km/h`} />
        <Stat icon={Cloud} label="Cloud" value={`${c.cloud}%`} />
      </div>

      <div className="mt-4 flex items-center justify-between rounded-xl bg-white/5 px-4 py-2.5 text-xs text-offwhite/70">
        <span className="flex items-center gap-1.5"><Sunrise className="h-4 w-4 text-warn" /> {c.sunrise}</span>
        <span className="flex items-center gap-1.5"><Sunset className="h-4 w-4 text-offwhite/50" /> {c.sunset}</span>
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: typeof Droplets; label: string; value: string }) {
  return (
    <div className="rounded-xl bg-white/5 px-3 py-2.5">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wide text-offwhite/50">
        <Icon className="h-3.5 w-3.5" /> {label}
      </div>
      <div className="mt-1 font-semibold">{value}</div>
    </div>
  );
}

export function HourlyForecast({ weather }: { weather: WeatherData }) {
  return (
    <div className="glass rounded-3xl p-5">
      <div className="label-eyebrow mb-4">Hourly forecast</div>
      <div className="no-scrollbar flex gap-3 overflow-x-auto">
        {weather.hourly.map((h, i) => (
          <div key={i} className="flex min-w-[64px] flex-col items-center gap-2 rounded-2xl bg-white/5 px-3 py-3">
            <span className="text-xs text-offwhite/60">{h.label}</span>
            <WeatherIcon icon={h.icon} className="h-7 w-7" />
            <span className="font-bold">{h.temp}°</span>
            <span className="flex items-center gap-0.5 text-[10px] text-leaf-sage">
              <CloudRain className="h-3 w-3" /> {h.rain_prob}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
