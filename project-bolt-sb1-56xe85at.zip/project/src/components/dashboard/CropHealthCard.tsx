import { Leaf, Activity, Droplets, Bug } from 'lucide-react';

export function CropHealthCard({ health }: { health: number }) {
  const r = 52;
  const c = 2 * Math.PI * r;
  const offset = c - (health / 100) * c;
  const color = health >= 75 ? '#76B85A' : health >= 50 ? '#E8B85A' : '#D86A5B';
  return (
    <div className="glass-strong rounded-3xl p-5 shadow-glass">
      <div className="label-eyebrow">Crop health</div>
      <div className="mt-3 flex items-center gap-5">
        <div className="relative grid place-items-center" style={{ width: 120, height: 120 }}>
          <svg width="120" height="120" className="-rotate-90">
            <circle cx="60" cy="60" r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="8" />
            <circle
              cx="60" cy="60" r={r} fill="none" stroke={color} strokeWidth="8" strokeLinecap="round"
              strokeDasharray={c} strokeDashoffset={offset}
              style={{ transition: 'stroke-dashoffset 1s ease-out' }}
            />
          </svg>
          <div className="absolute text-center">
            <div className="text-2xl font-extrabold" style={{ color }}>{health}%</div>
            <div className="text-[10px] uppercase text-offwhite/50">Healthy</div>
          </div>
        </div>
        <div className="flex-1 space-y-2.5">
          <Row icon={Leaf} label="Leaf condition" value="Good" color="text-leaf-fresh" />
          <Row icon={Activity} label="Disease risk" value="Moderate" color="text-warn" />
          <Row icon={Droplets} label="Irrigation" value="Adequate" color="text-leaf-sage" />
          <Row icon={Bug} label="Pest risk" value="Low" color="text-leaf-fresh" />
        </div>
      </div>
    </div>
  );
}

function Row({ icon: Icon, label, value, color }: { icon: typeof Leaf; label: string; value: string; color: string }) {
  return (
    <div className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2">
      <span className="flex items-center gap-2 text-sm text-offwhite/70">
        <Icon className="h-4 w-4" /> {label}
      </span>
      <span className={`text-sm font-semibold ${color}`}>{value}</span>
    </div>
  );
}
