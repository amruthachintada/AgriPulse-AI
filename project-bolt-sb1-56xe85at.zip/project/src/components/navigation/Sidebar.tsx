import { Home, ScanLine, MapPinned, Cloud, History, Bell, Settings, LogOut } from 'lucide-react';
import { LogoWordmark } from '@/components/ui/Logo';
import { useApp } from '@/lib/app';
import { useAuth } from '@/lib/auth';

export function Sidebar({ current, onNavigate }: { current: string; onNavigate: (p: string) => void }) {
  const { t } = useApp();
  const { signOut } = useAuth();

  const items = [
    { icon: Home, label: t('dashboard'), path: '/dashboard' },
    { icon: ScanLine, label: t('cropAnalysis'), path: '/analyze' },
    { icon: MapPinned, label: t('myFields'), path: '/fields' },
    { icon: Cloud, label: t('weather'), path: '/weather' },
    { icon: History, label: t('cropHistory'), path: '/history' },
    { icon: Bell, label: t('advisories'), path: '/advisories' },
    { icon: Settings, label: t('settings'), path: '/settings' },
  ];

  return (
    <aside className="fixed left-0 top-0 bottom-0 hidden w-64 flex-col border-r border-white/8 bg-bg-deep/80 p-4 backdrop-blur-glass lg:flex">
      <button onClick={() => onNavigate('/dashboard')} className="mb-8 mt-2 flex items-center">
        <LogoWordmark />
      </button>
      <nav className="flex flex-1 flex-col gap-1">
        {items.map((it) => {
          const active = current === it.path;
          return (
            <button
              key={it.path}
              onClick={() => onNavigate(it.path)}
              className={`flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition ${
                active
                  ? 'bg-leaf/15 text-leaf-fresh ring-1 ring-leaf/30 shadow-glow-sm'
                  : 'text-offwhite/65 hover:bg-white/5 hover:text-offwhite'
              }`}
            >
              <it.icon className="h-5 w-5" />
              {it.label}
            </button>
          );
        })}
      </nav>
      <button
        onClick={signOut}
        className="mt-2 flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-offwhite/60 hover:bg-danger/10 hover:text-danger"
      >
        <LogOut className="h-5 w-5" />
        {t('logout')}
      </button>
    </aside>
  );
}
