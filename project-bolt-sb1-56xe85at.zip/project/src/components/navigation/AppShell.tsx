import { type ReactNode } from 'react';
import { ArrowLeft, Bell } from 'lucide-react';
import { Sidebar } from './Sidebar';
import { BottomNav } from './BottomNav';
import { useRouter } from '@/lib/router';

const titles: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/analyze': 'Analyze',
  '/fields': 'My Fields',
  '/weather': 'Weather',
  '/history': 'Crop History',
  '/advisories': 'Advisories',
  '/settings': 'Settings',
};

export function AppShell({ children, current }: { children: ReactNode; current: string }) {
  const { navigate } = useRouter();

  return (
    <div className="bg-botanical min-h-screen">
      <Sidebar current={current} onNavigate={navigate} />

      {/* Mobile header */}
      <header className="sticky top-0 z-40 flex items-center justify-between px-4 py-3 glass-nav lg:hidden">
        <button onClick={() => navigate('/dashboard')} className="btn-ghost -ml-2">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <span className="text-base font-bold">{titles[current] ?? 'AgriPulse AI'}</span>
        <button onClick={() => navigate('/advisories')} className="btn-ghost -mr-2">
          <Bell className="h-5 w-5" />
        </button>
      </header>

      <main className="px-4 pb-28 pt-4 lg:pl-64 lg:pb-10">
        <div className="mx-auto max-w-6xl lg:px-6">{children}</div>
      </main>

      <BottomNav current={current} onNavigate={navigate} />
    </div>
  );
}
