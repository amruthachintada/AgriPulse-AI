import { useState } from 'react';
import { Menu, X, ScanLine } from 'lucide-react';
import { LogoWordmark } from '@/components/ui/Logo';
import { useApp } from '@/lib/app';

export function Navbar({ onNavigate }: { onNavigate: (path: string) => void }) {
  const { t } = useApp();
  const [open, setOpen] = useState(false);

  const links = [
    { label: t('home'), path: '/' },
    { label: t('cropAnalysis'), path: '/analyze' },
    { label: t('weather'), path: '/weather' },
    { label: t('advisories'), path: '/advisories' },
  ];

  const go = (p: string) => {
    onNavigate(p);
    setOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <div className="glass-nav mx-auto mt-3 flex max-w-6xl items-center justify-between rounded-2xl px-4 py-2.5 sm:px-5">
        <button onClick={() => go('/')} className="flex items-center">
          <LogoWordmark compact />
        </button>
        <nav className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <button
              key={l.path}
              onClick={() => go(l.path)}
              className="rounded-lg px-3 py-2 text-sm font-medium text-offwhite/70 transition hover:bg-white/5 hover:text-offwhite"
            >
              {l.label}
            </button>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <button onClick={() => go('/analyze')} className="btn-primary hidden sm:inline-flex !px-4 !py-2 text-sm">
            <ScanLine className="h-4 w-4" />
            {t('analyzeMyCrop')}
          </button>
          <button onClick={() => setOpen(!open)} className="btn-ghost md:hidden">
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="mx-auto mt-2 max-w-6xl px-3 md:hidden">
          <div className="glass-strong rounded-2xl p-2 animate-slide-up">
            {links.map((l) => (
              <button
                key={l.path}
                onClick={() => go(l.path)}
                className="block w-full rounded-lg px-4 py-3 text-left text-sm font-medium text-offwhite/80 hover:bg-white/5"
              >
                {l.label}
              </button>
            ))}
            <button onClick={() => go('/analyze')} className="btn-primary mt-2 w-full">
              {t('analyzeMyCrop')}
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
