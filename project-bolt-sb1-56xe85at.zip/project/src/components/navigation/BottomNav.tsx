import { Home, ScanLine, MapPinned, Cloud, User } from 'lucide-react';
import { useApp } from '@/lib/app';

export function BottomNav({ current, onNavigate }: { current: string; onNavigate: (p: string) => void }) {
  const { t } = useApp();
  const items = [
    { icon: Home, label: t('home'), path: '/dashboard' },
    { icon: ScanLine, label: t('analyze'), path: '/analyze' },
    { icon: MapPinned, label: t('crops'), path: '/fields' },
    { icon: Cloud, label: t('weather'), path: '/weather' },
    { icon: User, label: t('profile'), path: '/settings' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 px-3 pb-3 lg:hidden">
      <div className="glass-nav mx-auto flex max-w-md items-end justify-around rounded-2xl px-2 py-2 shadow-glass">
        {items.map((it) => {
          const active = current === it.path;
          const isAnalyze = it.path === '/analyze';
          return (
            <button
              key={it.path}
              onClick={() => onNavigate(it.path)}
              className={`flex flex-col items-center gap-1 rounded-xl px-3 py-1.5 transition ${
                isAnalyze ? '-mt-5' : ''
              }`}
            >
              <span
                className={`grid place-items-center rounded-xl transition ${
                  isAnalyze
                    ? 'h-12 w-12 bg-leaf-fresh text-bg-deep shadow-glow'
                    : active
                    ? 'h-9 w-9 bg-leaf/20 text-leaf-fresh ring-1 ring-leaf/30'
                    : 'h-9 w-9 text-offwhite/55'
                }`}
              >
                <it.icon className={isAnalyze ? 'h-6 w-6' : 'h-5 w-5'} />
              </span>
              <span className={`text-[10px] font-medium ${active ? 'text-leaf-fresh' : 'text-offwhite/55'}`}>
                {it.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
