import { useEffect, useState } from 'react';
import { scanSteps } from '@/lib/mockAI';

export function AIScanner({ image, onDone }: { image: string; onDone: () => void }) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (step >= scanSteps.length) {
      const t = setTimeout(onDone, 400);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setStep((s) => s + 1), 900);
    return () => clearTimeout(t);
  }, [step, onDone]);

  return (
    <div className="grid place-items-center py-8">
      <div className="relative w-full max-w-sm">
        <div className="relative overflow-hidden rounded-3xl glass-strong p-2 shadow-glass">
          <img src={image} alt="Analyzing" className="h-72 w-full rounded-2xl object-cover sm:h-80" />
          <div className="pointer-events-none absolute inset-2 overflow-hidden rounded-2xl">
            <div className="absolute inset-0 bg-gradient-to-b from-leaf/10 via-transparent to-bg-deep/50" />
            <div className="absolute left-0 right-0 h-0.5 bg-leaf-fresh/80 shadow-glow animate-scan-line" />
            {/* grid */}
            <div className="absolute inset-0 opacity-20" style={{
              backgroundImage: 'linear-gradient(rgba(118,184,90,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(118,184,90,0.3) 1px, transparent 1px)',
              backgroundSize: '32px 32px',
            }} />
            {/* detection nodes */}
            <span className="absolute left-8 top-12 h-3 w-3 animate-pulse-soft rounded-full bg-warn shadow-glow" />
            <span className="absolute right-10 top-24 h-2.5 w-2.5 animate-pulse-soft rounded-full bg-leaf-fresh shadow-glow" />
            <span className="absolute bottom-20 left-12 h-2.5 w-2.5 animate-pulse-soft rounded-full bg-warn shadow-glow" />
            <span className="absolute bottom-12 right-16 h-2 w-2 animate-pulse-soft rounded-full bg-leaf-fresh shadow-glow" />
          </div>
        </div>
      </div>

      <div className="mt-6 w-full max-w-sm space-y-2">
        {scanSteps.map((s, i) => (
          <div
            key={i}
            className={`flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm transition ${
              i < step
                ? 'bg-leaf/10 text-leaf-fresh'
                : i === step
                ? 'glass-strong text-offwhite'
                : 'text-offwhite/30'
            }`}
          >
            <span className={`h-2 w-2 rounded-full ${i < step ? 'bg-leaf-fresh' : i === step ? 'animate-pulse-soft bg-leaf-fresh' : 'bg-white/20'}`} />
            {i < step ? '✓ ' : ''}{s}
          </div>
        ))}
      </div>
    </div>
  );
}
