import {
  AlertTriangle, CheckCircle2, XCircle, ShieldAlert, CalendarClock,
  CloudRain, Leaf, Eye, Activity, Sprout, Ban,
} from 'lucide-react';
import { ConfidenceScore, SeverityBadge } from '@/components/ui/ConfidenceScore';
import { WeatherIcon } from '@/components/ui/WeatherIcon';
import type { CropAnalysisResult, WeatherData, ActionWindow } from '@/types';

export function ResultView({
  result,
  image,
  weather,
  window,
  crop,
}: {
  result: CropAnalysisResult;
  image: string;
  weather: WeatherData;
  window: ActionWindow;
  crop: string;
}) {
  return (
    <div className="space-y-5 animate-fade-in">
      {/* Scan result header */}
      <div className="glass-strong rounded-3xl p-5 shadow-glass">
        <div className="label-eyebrow">Scan result</div>
        <div className="mt-4 flex flex-col gap-5 sm:flex-row sm:items-center">
          <div className="relative overflow-hidden rounded-2xl">
            <img src={image} alt={crop} className="h-40 w-40 object-cover" />
            <div className="pointer-events-none absolute inset-0 ring-2 ring-leaf/40 rounded-2xl" />
            <span className="absolute bottom-2 left-2 rounded-full glass px-2 py-0.5 text-[10px]">{crop}</span>
          </div>
          <div className="flex-1">
            <div className="label-eyebrow">Likely issue</div>
            <h2 className="mt-1 text-2xl font-extrabold tracking-tight sm:text-3xl">{result.diagnosis}</h2>
            <div className="mt-2 flex items-center gap-2">
              <SeverityBadge severity={result.severity} />
              <span className="rounded-full bg-white/5 px-3 py-1 text-xs text-offwhite/60">{result.category}</span>
            </div>
          </div>
          <ConfidenceScore value={result.confidence} size={120} />
        </div>
      </div>

      {/* What we found */}
      <Section title="What we found" icon={Eye}>
        <div className="grid gap-3 sm:grid-cols-3">
          <InfoCard icon={AlertTriangle} title="Visible symptoms" items={result.symptoms} color="text-warn" />
          <InfoCard icon={Activity} title="Possible cause" items={result.possible_causes} color="text-leaf-sage" />
          <InfoCard icon={CloudRain} title="Environmental factors" items={[weather.current.condition, `Humidity ${weather.current.humidity}%`, `Rain ${weather.current.rain_prob}%`]} color="text-leaf-fresh" />
        </div>
      </Section>

      {/* What should I do */}
      <Section title="What should I do?" icon={CheckCircle2}>
        <div className="grid gap-3 sm:grid-cols-2">
          {result.recommended_actions.map((a, i) => (
            <ActionCard key={i} n={i + 1} text={a} />
          ))}
        </div>
      </Section>

      {/* Weather + crop insight */}
      <div className="glass-strong rounded-3xl p-5 shadow-glass">
        <div className="label-eyebrow">Weather + crop insight</div>
        <div className="mt-4 flex flex-col items-stretch gap-3 sm:flex-row sm:items-center">
          <div className="flex-1 rounded-2xl bg-white/5 p-4">
            <div className="flex items-center gap-2 text-sm text-offwhite/70">
              <Leaf className="h-4 w-4 text-leaf-fresh" /> Crop condition
            </div>
            <p className="mt-2 text-sm">{result.symptoms[0]}</p>
          </div>
          <div className="grid place-items-center text-leaf-sage">+</div>
          <div className="flex-1 rounded-2xl bg-white/5 p-4">
            <div className="flex items-center gap-2 text-sm text-offwhite/70">
              <WeatherIcon icon={weather.current.icon} className="h-4 w-4" /> Weather
            </div>
            <p className="mt-2 text-sm">{weather.current.condition}, {weather.current.humidity}% humidity, rain {weather.current.rain_prob}%</p>
          </div>
          <div className="grid place-items-center text-leaf-sage">=</div>
          <div className="flex-1 rounded-2xl bg-warn/10 p-4 ring-1 ring-warn/30">
            <div className="flex items-center gap-2 text-sm text-warn">
              <ShieldAlert className="h-4 w-4" /> Risk
            </div>
            <p className="mt-2 text-sm">{result.weather_risk}</p>
          </div>
        </div>
      </div>

      {/* Action window */}
      <div className={`rounded-3xl p-5 shadow-glass ${window.suitable ? 'glass-strong ring-1 ring-leaf/30' : 'glass-strong ring-1 ring-warn/40'}`}>
        <div className="flex items-center justify-between">
          <div className="label-eyebrow">Best action window</div>
          <span className={`rounded-full px-3 py-1 text-xs font-bold uppercase ${window.suitable ? 'bg-leaf/15 text-leaf-fresh' : 'bg-warn/15 text-warn'}`}>
            {window.label}
          </span>
        </div>
        <div className="mt-3 text-xl font-bold">{window.time}</div>
        <div className="mt-3 grid grid-cols-3 gap-3 text-center">
          <Mini label="Rain risk" value={window.rain_risk} />
          <Mini label="Wind" value={window.wind} />
          <Mini label="Humidity" value={`${window.humidity}%`} />
        </div>
        <p className="mt-3 text-sm text-offwhite/70">{window.reason}</p>
      </div>

      {/* What not to do */}
      <Section title="What NOT to do" icon={Ban}>
        <div className="space-y-2">
          {result.what_not_to_do.map((d, i) => (
            <div key={i} className="flex items-start gap-3 rounded-xl bg-danger/5 px-4 py-3 ring-1 ring-danger/20">
              <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-danger" />
              <span className="text-sm">{d}</span>
            </div>
          ))}
        </div>
      </Section>

      {/* Prevention */}
      <Section title="Prevention" icon={Sprout}>
        <div className="grid gap-3 sm:grid-cols-2">
          {result.preventive_measures.map((p, i) => (
            <div key={i} className="flex items-start gap-3 rounded-xl bg-white/5 px-4 py-3">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-leaf-fresh" />
              <span className="text-sm">{p}</span>
            </div>
          ))}
        </div>
      </Section>

      {/* Next check */}
      <div className="glass-strong flex items-center gap-4 rounded-3xl p-5 shadow-glass">
        <div className="grid h-12 w-12 place-items-center rounded-2xl bg-leaf/15 ring-1 ring-leaf/30">
          <CalendarClock className="h-6 w-6 text-leaf-fresh" />
        </div>
        <div>
          <div className="label-eyebrow">Next check</div>
          <p className="mt-1 font-semibold">{result.follow_up}</p>
        </div>
      </div>

      <p className="px-2 text-center text-xs text-offwhite/40">
        AI guidance is advisory and not a guaranteed diagnosis. For chemical treatments, follow the product label and local agricultural recommendations. For serious issues, consult a qualified agronomist.
      </p>
    </div>
  );
}

function Section({ title, icon: Icon, children }: { title: string; icon: typeof Eye; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-3 flex items-center gap-2">
        <Icon className="h-5 w-5 text-leaf-fresh" />
        <h3 className="text-lg font-bold">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function InfoCard({ icon: Icon, title, items, color }: { icon: typeof Eye; title: string; items: string[]; color: string }) {
  return (
    <div className="glass rounded-2xl p-4">
      <div className={`flex items-center gap-2 text-sm font-semibold ${color}`}>
        <Icon className="h-4 w-4" /> {title}
      </div>
      <ul className="mt-2 space-y-1.5 text-sm text-offwhite/70">
        {items.map((s, i) => (
          <li key={i} className="flex items-start gap-2">
            <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-current" /> {s}
          </li>
        ))}
      </ul>
    </div>
  );
}

function ActionCard({ n, text }: { n: number; text: string }) {
  return (
    <div className="glass flex items-start gap-3 rounded-2xl p-4">
      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-leaf/15 text-sm font-bold text-leaf-fresh ring-1 ring-leaf/30">
        {String(n).padStart(2, '0')}
      </span>
      <p className="text-sm">{text}</p>
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-white/5 px-2 py-2.5">
      <div className="text-[10px] uppercase tracking-wide text-offwhite/50">{label}</div>
      <div className="mt-0.5 text-sm font-semibold">{value}</div>
    </div>
  );
}
