import { useRef, useState } from 'react';
import { Upload, Camera, ImagePlus, X } from 'lucide-react';

export function UploadBox({
  onUpload,
  preview,
  onRemove,
}: {
  onUpload: (file: File, dataUrl: string) => void;
  preview: string | null;
  onRemove: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState('');

  const handleFile = (file: File) => {
    setError('');
    const valid = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    if (!valid.includes(file.type)) {
      setError('Please upload a JPG, PNG, or WEBP image.');
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setError('Image is too large. Please use an image under 8MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => onUpload(file, reader.result as string);
    reader.readAsDataURL(file);
  };

  if (preview) {
    return (
      <div className="relative overflow-hidden rounded-3xl glass-strong p-2 shadow-glass">
        <img src={preview} alt="Crop preview" className="h-72 w-full rounded-2xl object-cover sm:h-80" />
        <div className="absolute right-4 top-4 flex gap-2">
          <button onClick={() => inputRef.current?.click()} className="btn-secondary !py-2 !px-3 text-sm">
            <ImagePlus className="h-4 w-4" /> Replace
          </button>
          <button onClick={onRemove} className="btn-secondary !py-2 !px-3 text-sm">
            <X className="h-4 w-4" /> Remove
          </button>
        </div>
        <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
      </div>
    );
  }

  return (
    <div>
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
        }}
        className={`grid place-items-center rounded-3xl border-2 border-dashed p-8 text-center transition sm:p-12 ${
          dragging ? 'border-leaf-fresh bg-leaf/10' : 'border-white/15 glass'
        }`}
      >
        <div className="grid h-16 w-16 place-items-center rounded-2xl bg-leaf/15 ring-1 ring-leaf/30">
          <Upload className="h-7 w-7 text-leaf-fresh" />
        </div>
        <p className="mt-4 font-semibold">Drag & Drop your image here</p>
        <p className="mt-1 text-sm text-offwhite/50">JPG, PNG, or WEBP · max 8MB</p>
        <div className="mt-5 flex flex-wrap justify-center gap-3">
          <button onClick={() => inputRef.current?.click()} className="btn-secondary">
            <ImagePlus className="h-4 w-4" /> Browse
          </button>
          <button onClick={() => cameraRef.current?.click()} className="btn-primary">
            <Camera className="h-4 w-4" /> Take Photo
          </button>
        </div>
      </div>
      {error && (
        <div className="mt-3 rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger ring-1 ring-danger/30">
          {error}
        </div>
      )}
      <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
      <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
    </div>
  );
}
