import { Leaf } from 'lucide-react';

export function Logo({ className = 'h-9 w-9' }: { className?: string }) {
  return (
    <div className={`${className} relative grid place-items-center rounded-xl bg-leaf/15 ring-1 ring-leaf/30`}>
      <Leaf className="h-1/2 w-1/2 text-leaf-fresh" strokeWidth={2.4} />
      <span className="absolute inset-0 rounded-xl shadow-glow-sm opacity-60" />
    </div>
  );
}

export function LogoWordmark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <Logo className={compact ? 'h-8 w-8' : 'h-10 w-10'} />
      <div className="leading-tight">
        <div className={`font-extrabold tracking-tight ${compact ? 'text-base' : 'text-lg'}`}>
          AgriPulse <span className="text-leaf-fresh">AI</span>
        </div>
        {!compact && (
          <div className="text-[10px] uppercase tracking-[0.2em] text-leaf-sage/70">
            Smarter Fields
          </div>
        )}
      </div>
    </div>
  );
}
