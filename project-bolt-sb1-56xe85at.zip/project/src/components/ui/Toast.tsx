import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';

type ToastType = 'success' | 'error' | 'info';
interface Toast {
  id: number;
  message: string;
  type: ToastType;
}

const ToastCtx = createContext<{ push: (m: string, t?: ToastType) => void } | undefined>(undefined);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const push = useCallback((message: string, type: ToastType = 'info') => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000);
  }, []);

  const remove = (id: number) => setToasts((t) => t.filter((x) => x.id !== id));

  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      <div className="fixed bottom-24 right-4 z-[100] flex flex-col gap-2 sm:bottom-6">
        {toasts.map((t) => (
          <div
            key={t.id}
            className="glass-strong flex items-start gap-3 rounded-xl px-4 py-3 shadow-glass animate-slide-up max-w-xs"
          >
            {t.type === 'success' && <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-leaf-fresh" />}
            {t.type === 'error' && <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-danger" />}
            {t.type === 'info' && <Info className="mt-0.5 h-5 w-5 shrink-0 text-leaf-sage" />}
            <p className="text-sm text-offwhite flex-1">{t.message}</p>
            <button onClick={() => remove(t.id)} className="text-offwhite/40 hover:text-offwhite">
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastCtx);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}
