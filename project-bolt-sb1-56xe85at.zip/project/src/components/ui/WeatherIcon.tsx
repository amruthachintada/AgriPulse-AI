import { Sun, Cloud, CloudRain, CloudSun, CloudSnow, Wind, Droplets } from 'lucide-react';

export function WeatherIcon({ icon, className = 'h-6 w-6' }: { icon: string; className?: string }) {
  switch (icon) {
    case 'sun':
      return <Sun className={`${className} text-warn`} />;
    case 'cloud':
      return <Cloud className={`${className} text-offwhite/70`} />;
    case 'partly-cloudy':
      return <CloudSun className={`${className} text-leaf-sage`} />;
    case 'cloud-rain':
      return <CloudRain className={`${className} text-leaf-fresh`} />;
    case 'snow':
      return <CloudSnow className={`${className} text-offwhite/80`} />;
    case 'wind':
      return <Wind className={`${className} text-leaf-sage`} />;
    case 'droplet':
      return <Droplets className={`${className} text-leaf-fresh`} />;
    default:
      return <Sun className={`${className} text-warn`} />;
  }
}
