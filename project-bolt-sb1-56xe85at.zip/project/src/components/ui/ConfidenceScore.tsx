import type { Severity } from '@/types';

export function ConfidenceScore({ value, size = 120 }: { value: number; size?: number }) {
  const r = (size - 14) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (value / 100) * c;
  const color = value >= 75 ? '#76B85A' : value >= 60 ? '#E8B85A' : '#D86A5B';
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="7" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 1s ease-out' }}
        />
      </svg>
      <div className="absolute text-center">
        <div className="text-2xl font-bold" style={{ color }}>
          {value}%
        </div>
        <div className="text-[10px] uppercase tracking-wider text-offwhite/50">AI</div>
      </div>
    </div>
  );
}

export function SeverityBadge({ severity }: { severity: Severity }) {
  const map: Record<Severity, string> = {
    Low: 'bg-leaf/15 text-leaf-fresh ring-leaf/30',
    Moderate: 'bg-warn/15 text-warn ring-warn/30',
    High: 'bg-warn/20 text-warn ring-warn/40',
    Critical: 'bg-danger/15 text-danger ring-danger/40',
  };
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold uppercase tracking-wide ring-1 ${map[severity]}`}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {severity} Risk
    </span>
  );
}
