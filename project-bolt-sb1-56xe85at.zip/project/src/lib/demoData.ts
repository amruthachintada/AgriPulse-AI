import type { AnalysisRecord, Advisory, Field, WeatherData } from '@/types';

export const CROPS = [
  'Rice', 'Paddy', 'Cotton', 'Chilli', 'Tomato', 'Maize', 'Groundnut', 'Wheat', 'Sugarcane', 'Other',
];

export const SOIL_TYPES = ['Loamy', 'Sandy', 'Clay', 'Silty', 'Peaty', 'Chalky', 'Saline'];
export const IRRIGATION_METHODS = ['Drip', 'Flood', 'Sprinkler', 'Rainfed', 'Furrow'];

export const demoWeather: WeatherData = {
  location: 'Vijayawada, Andhra Pradesh',
  current: {
    temp: 32,
    feels_like: 36,
    condition: 'Partly Cloudy',
    humidity: 68,
    rain_prob: 24,
    wind: 12,
    cloud: 45,
    icon: 'partly-cloudy',
    sunrise: '06:12',
    sunset: '18:34',
  },
  hourly: [
    { label: 'Now', temp: 32, rain_prob: 24, icon: 'partly-cloudy' },
    { label: '11AM', temp: 33, rain_prob: 18, icon: 'sun' },
    { label: '1PM', temp: 34, rain_prob: 12, icon: 'sun' },
    { label: '3PM', temp: 33, rain_prob: 20, icon: 'partly-cloudy' },
    { label: '5PM', temp: 31, rain_prob: 35, icon: 'cloud' },
    { label: '7PM', temp: 29, rain_prob: 48, icon: 'cloud-rain' },
  ],
  daily: [
    { day: 'Today', high: 34, low: 26, rain_prob: 24, icon: 'partly-cloudy' },
    { day: 'Tue', high: 33, low: 25, rain_prob: 62, icon: 'cloud-rain' },
    { day: 'Wed', high: 31, low: 24, rain_prob: 78, icon: 'cloud-rain' },
    { day: 'Thu', high: 32, low: 25, rain_prob: 40, icon: 'cloud' },
    { day: 'Fri', high: 34, low: 26, rain_prob: 15, icon: 'sun' },
    { day: 'Sat', high: 35, low: 27, rain_prob: 8, icon: 'sun' },
    { day: 'Sun', high: 33, low: 26, rain_prob: 22, icon: 'partly-cloudy' },
  ],
};

export const demoFields: Field[] = [
  {
    id: 'f1',
    name: 'My Paddy Field',
    location: 'Vijayawada, Andhra Pradesh',
    crop: 'Rice',
    area: '2.5 acres',
    crop_age: '45 days',
    irrigation: 'Flood',
    health: 82,
    created_at: new Date(Date.now() - 86400000 * 20).toISOString(),
  },
  {
    id: 'f2',
    name: 'Backyard Tomatoes',
    location: 'Vijayawada, Andhra Pradesh',
    crop: 'Tomato',
    area: '0.5 acres',
    crop_age: '30 days',
    irrigation: 'Drip',
    health: 68,
    created_at: new Date(Date.now() - 86400000 * 10).toISOString(),
  },
];

export const demoHistory: AnalysisRecord[] = [
  {
    id: 'h1',
    crop: 'Rice',
    image_url: '',
    diagnosis: 'Leaf Blight',
    confidence: 87,
    severity: 'Moderate',
    created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    result: {
      diagnosis: 'Leaf Blight',
      confidence: 87,
      severity: 'Moderate',
      category: 'Fungal',
      symptoms: ['Yellow lesions on leaf edges', 'Wilting tips', 'Dark streaks along veins'],
      possible_causes: ['High humidity', 'Standing water in field', 'Bacterial infection'],
      recommended_actions: ['Inspect nearby plants', 'Remove severely affected leaves', 'Improve drainage', 'Monitor weather before treatment'],
      preventive_measures: ['Improve field monitoring', 'Maintain appropriate irrigation', 'Remove affected plant material'],
      what_not_to_do: ['Do not overwater', 'Do not act immediately before expected rainfall', 'Do not use unverified chemical mixtures'],
      weather_risk: 'High humidity and upcoming rain increase fungal risk.',
      action_window: 'Tomorrow 4:00 PM – 6:00 PM',
      follow_up: 'Inspect the crop again in 48 hours.',
    },
  },
  {
    id: 'h2',
    crop: 'Tomato',
    image_url: '',
    diagnosis: 'Early Blight',
    confidence: 74,
    severity: 'Low',
    created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
    result: {
      diagnosis: 'Early Blight',
      confidence: 74,
      severity: 'Low',
      category: 'Fungal',
      symptoms: ['Dark concentric rings on lower leaves', 'Yellowing'],
      possible_causes: ['Alternaria fungus', 'Warm wet weather'],
      recommended_actions: ['Remove affected leaves', 'Improve airflow', 'Mulch around base'],
      preventive_measures: ['Crop rotation', 'Avoid overhead watering'],
      what_not_to_do: ['Do not compost infected leaves', 'Do not overwater'],
      weather_risk: 'Moderate — upcoming rain may spread spores.',
      action_window: 'Today 4:00 PM – 6:00 PM',
      follow_up: 'Inspect again in 72 hours.',
    },
  },
];

export const demoAdvisories: Advisory[] = [
  {
    id: 'a1',
    title: 'Heavy rain expected tomorrow',
    category: 'Weather',
    severity: 'High',
    date: new Date().toISOString(),
    explanation: 'Rain is expected tomorrow afternoon. Field activity and treatments should be delayed until conditions improve.',
    action: 'Delay any planned field treatment until after the rain clears.',
  },
  {
    id: 'a2',
    title: 'Leaf blight risk elevated',
    category: 'Crop Health',
    severity: 'Moderate',
    date: new Date(Date.now() - 86400000).toISOString(),
    explanation: 'High humidity combined with your recent leaf blight diagnosis increases fungal spread risk.',
    action: 'Inspect nearby plants and remove severely affected leaves.',
  },
  {
    id: 'a3',
    title: 'Good window for field activity',
    category: 'Weather',
    severity: 'Low',
    date: new Date(Date.now() - 86400000 * 2).toISOString(),
    explanation: 'Low rain probability and moderate wind make Friday afternoon suitable for field work.',
    action: 'Schedule non-treatment field activity for Friday 4–6 PM.',
  },
  {
    id: 'a4',
    title: 'Inspection reminder',
    category: 'Alerts',
    severity: 'Low',
    date: new Date(Date.now() - 86400000 * 3).toISOString(),
    explanation: 'Your paddy field is due for its 48-hour follow-up inspection.',
    action: 'Check the previously affected area for any spread.',
  },
];
