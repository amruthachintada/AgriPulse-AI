import type { CropAnalysisResult, Severity } from '@/types';

const diagnoses: Record<string, CropAnalysisResult> = {
  Rice: {
    diagnosis: 'Likely Leaf Blight',
    confidence: 87,
    severity: 'Moderate',
    category: 'Fungal / Bacterial',
    symptoms: ['Yellow lesions along leaf edges', 'Wilting leaf tips', 'Dark streaks following veins', 'Leaves drying from the tip'],
    possible_causes: ['Bacterial infection in standing water', 'High humidity', 'Excess nitrogen', 'Rain splash spreading bacteria'],
    recommended_actions: [
      'Inspect nearby plants for early signs',
      'Remove and destroy severely affected leaves',
      'Improve field drainage to reduce standing water',
      'Avoid fertilizer application until conditions stabilize',
      'Monitor weather before any field treatment',
    ],
    preventive_measures: [
      'Use disease-resistant varieties where available',
      'Maintain balanced nitrogen levels',
      'Ensure proper spacing for airflow',
      'Keep field margins clear of weeds',
    ],
    what_not_to_do: [
      'Do not overwater or flood the field',
      'Do not apply treatment immediately before expected rainfall',
      'Do not use unverified chemical mixtures',
      'Do not ignore rapid spread across rows',
    ],
    weather_risk: 'High humidity and upcoming rain increase fungal and bacterial spread risk.',
    action_window: 'Tomorrow 4:00 PM – 6:00 PM',
    follow_up: 'Inspect the crop again in 48 hours.',
  },
  Paddy: {
    diagnosis: 'Likely Leaf Blight',
    confidence: 84,
    severity: 'Moderate',
    category: 'Fungal / Bacterial',
    symptoms: ['Yellow lesions on leaf edges', 'Wilting tips', 'Dark streaks along veins'],
    possible_causes: ['Bacterial infection', 'High humidity', 'Standing water'],
    recommended_actions: [
      'Inspect nearby plants',
      'Remove severely affected leaves',
      'Improve drainage',
      'Monitor weather before treatment',
    ],
    preventive_measures: ['Use resistant varieties', 'Balance nitrogen', 'Improve spacing'],
    what_not_to_do: ['Do not overwater', 'Do not treat before rain', 'Do not use unverified chemicals'],
    weather_risk: 'Humidity and rain raise fungal risk.',
    action_window: 'Tomorrow 4:00 PM – 6:00 PM',
    follow_up: 'Inspect again in 48 hours.',
  },
  Cotton: {
    diagnosis: 'Likely Bacterial Blight',
    confidence: 79,
    severity: 'Moderate',
    category: 'Bacterial',
    symptoms: ['Angular water-soaked lesions on leaves', 'Yellow halos around spots', 'Leaf curling'],
    possible_causes: ['Bacterial infection via rain splash', 'High humidity', 'Infected seed'],
    recommended_actions: [
      'Remove and destroy affected leaves',
      'Improve row spacing for airflow',
      'Avoid working in the field when leaves are wet',
      'Monitor weather before treatment',
    ],
    preventive_measures: ['Use certified disease-free seed', 'Rotate crops', 'Control weeds'],
    what_not_to_do: ['Do not splash water between plants', 'Do not treat before rain', 'Do not reuse infected seed'],
    weather_risk: 'Rain and humidity increase bacterial spread.',
    action_window: 'Friday 4:00 PM – 6:00 PM',
    follow_up: 'Inspect again in 48–72 hours.',
  },
  Chilli: {
    diagnosis: 'Likely Leaf Curl Virus',
    confidence: 72,
    severity: 'High',
    category: 'Viral',
    symptoms: ['Upward curling leaves', 'Yellowing between veins', 'Stunted growth', 'Thrips presence possible'],
    possible_causes: ['Thrips-transmitted virus', 'Whitefly activity', 'Stress'],
    recommended_actions: [
      'Inspect for thrips and whiteflies under leaves',
      'Remove and destroy infected plants if widespread',
      'Use yellow sticky traps to monitor insects',
      'Consult a local agronomist for resistant varieties',
    ],
    preventive_measures: ['Control insect vectors early', 'Use reflective mulches', 'Remove weeds near field'],
    what_not_to_do: ['Do not spray broad insecticides without label guidance', 'Do not ignore vector presence'],
    weather_risk: 'Warm dry conditions favor thrips activity.',
    action_window: 'Today 5:00 PM – 6:30 PM',
    follow_up: 'Inspect again in 48 hours.',
  },
  Tomato: {
    diagnosis: 'Likely Early Blight',
    confidence: 74,
    severity: 'Low',
    category: 'Fungal',
    symptoms: ['Dark concentric rings on lower leaves', 'Yellowing around spots', 'Leaf drop'],
    possible_causes: ['Alternaria fungus', 'Warm wet weather', 'Poor airflow'],
    recommended_actions: [
      'Remove affected lower leaves',
      'Improve staking and airflow',
      'Mulch around the base to reduce splash',
      'Monitor humidity and rain',
    ],
    preventive_measures: ['Crop rotation', 'Avoid overhead watering', 'Remove plant debris'],
    what_not_to_do: ['Do not compost infected leaves', 'Do not overwater', 'Do not treat before rain'],
    weather_risk: 'Upcoming rain may spread fungal spores.',
    action_window: 'Today 4:00 PM – 6:00 PM',
    follow_up: 'Inspect again in 72 hours.',
  },
  Maize: {
    diagnosis: 'Likely Northern Leaf Blight',
    confidence: 70,
    severity: 'Moderate',
    category: 'Fungal',
    symptoms: ['Cigar-shaped grey lesions', 'Yellowing around lesions', 'Lower leaves affected first'],
    possible_causes: ['Fungal infection', 'High humidity', 'Moderate temperatures'],
    recommended_actions: [
      'Remove affected lower leaves',
      'Improve field drainage',
      'Monitor weather before treatment',
    ],
    preventive_measures: ['Use resistant hybrids', 'Rotate crops', 'Manage residue'],
    what_not_to_do: ['Do not treat before rain', 'Do not ignore rapid spread'],
    weather_risk: 'Humidity and rain favor fungal growth.',
    action_window: 'Friday 4:00 PM – 6:00 PM',
    follow_up: 'Inspect again in 72 hours.',
  },
  Groundnut: {
    diagnosis: 'Likely Leaf Rust',
    confidence: 68,
    severity: 'Moderate',
    category: 'Fungal',
    symptoms: ['Rust-orange pustules on leaves', 'Yellowing', 'Premature defoliation'],
    possible_causes: ['Fungal spores', 'High humidity', 'Cool nights'],
    recommended_actions: ['Remove affected leaves', 'Improve airflow', 'Monitor weather'],
    preventive_measures: ['Use resistant varieties', 'Rotate crops'],
    what_not_to_do: ['Do not treat before rain', 'Do not overwater'],
    weather_risk: 'Cool humid nights increase rust risk.',
    action_window: 'Friday 4:00 PM – 6:00 PM',
    follow_up: 'Inspect again in 72 hours.',
  },
  Wheat: {
    diagnosis: 'Likely Leaf Rust',
    confidence: 76,
    severity: 'Moderate',
    category: 'Fungal',
    symptoms: ['Orange-brown pustules on leaves', 'Yellowing', 'Reduced grain fill'],
    possible_causes: ['Rust fungus', 'Cool moist weather'],
    recommended_actions: ['Remove affected leaves', 'Monitor weather', 'Improve airflow'],
    preventive_measures: ['Use resistant varieties', 'Timely planting'],
    what_not_to_do: ['Do not treat before rain'],
    weather_risk: 'Cool moist conditions favor rust.',
    action_window: 'Friday 4:00 PM – 6:00 PM',
    follow_up: 'Inspect again in 72 hours.',
  },
  Sugarcane: {
    diagnosis: 'Likely Red Rot',
    confidence: 65,
    severity: 'High',
    category: 'Fungal',
    symptoms: ['Reddening of internodes', 'White patches inside stalks', 'Yellowing leaves', 'Stunted growth'],
    possible_causes: ['Fungal infection', 'Waterlogging', 'Insect damage entry'],
    recommended_actions: [
      'Inspect stalks internally',
      'Remove severely affected stools',
      'Improve drainage',
      'Consult a local agronomist',
    ],
    preventive_measures: ['Use healthy setts', 'Rotate crops', 'Avoid waterlogging'],
    what_not_to_do: ['Do not reuse infected setts', 'Do not waterlog the field'],
    weather_risk: 'Waterlogging and rain increase risk.',
    action_window: 'Friday 4:00 PM – 6:00 PM',
    follow_up: 'Inspect again in 48 hours.',
  },
};

const generic: CropAnalysisResult = {
  diagnosis: 'Possible Nutrient Deficiency',
  confidence: 58,
  severity: 'Low',
  category: 'Environmental Stress',
  symptoms: ['General yellowing of leaves', 'Reduced vigour', 'Uneven growth'],
  possible_causes: ['Nutrient deficiency', 'Water stress', 'Soil imbalance'],
  recommended_actions: [
    'Inspect soil condition and drainage',
    'Check irrigation consistency',
    'Consult a local agronomist for a soil test',
    'Upload a clearer image for a more confident assessment',
  ],
  preventive_measures: ['Maintain balanced fertilization', 'Regular soil testing', 'Proper irrigation'],
  what_not_to_do: ['Do not over-fertilize without testing', 'Do not ignore persistent yellowing'],
  weather_risk: 'Stress may worsen in extreme weather.',
  action_window: 'Today 4:00 PM – 6:00 PM',
  follow_up: 'Inspect again in 48–72 hours.',
};

export async function analyzeCropMock(crop: string, image: string): Promise<CropAnalysisResult> {
  await new Promise((r) => setTimeout(r, 100));
  const base = diagnoses[crop] ?? generic;
  const result = { ...base };
  if (image) {
    // small deterministic variation so repeated analyses feel real
    const seed = image.length % 7;
    result.confidence = Math.max(55, Math.min(94, base.confidence + (seed - 3)));
    if (result.confidence < 60) {
      result.severity = 'Low';
    }
  }
  return result;
}

export const scanSteps = [
  'Reading your plant...',
  'Analyzing visible symptoms...',
  'Evaluating crop condition...',
  'Checking weather conditions...',
  'Preparing your advisory...',
];

export const severityColor: Record<Severity, string> = {
  Low: 'text-leaf-fresh',
  Moderate: 'text-warn',
  High: 'text-warn',
  Critical: 'text-danger',
};
