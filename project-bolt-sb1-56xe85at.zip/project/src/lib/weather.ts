import type { ActionWindow, WeatherData } from '@/types';
import { demoWeather } from './demoData';

export const isWeatherDemo = !import.meta.env.VITE_WEATHER_API_KEY;

export async function getWeather(location?: string): Promise<WeatherData> {
  void location;
  await new Promise((r) => setTimeout(r, 200));
  return demoWeather;
}

export function getActionWindow(weather: WeatherData): ActionWindow {
  const tomorrow = weather.daily[1];
  const rainSoon = weather.hourly.some((h) => h.rain_prob > 45);
  if (rainSoon) {
    return {
      label: 'WAIT BEFORE ACTING',
      time: 'Not now — rain expected soon',
      rain_risk: 'High',
      wind: `${weather.current.wind} km/h`,
      humidity: weather.current.humidity,
      suitable: false,
      reason: 'Rain is expected soon and may affect field activity or wash off treatments.',
    };
  }
  return {
    label: 'GOOD WINDOW FOR FIELD ACTIVITY',
    time: 'Tomorrow 4:00 PM – 6:00 PM',
    rain_risk: tomorrow ? (tomorrow.rain_prob > 50 ? 'High' : tomorrow.rain_prob > 30 ? 'Moderate' : 'Low') : 'Low',
    wind: 'Moderate',
    humidity: 65,
    suitable: true,
    reason: 'Conditions appear more suitable for field activity during this period.',
  };
}
