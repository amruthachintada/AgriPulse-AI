import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { supabase, isSupabaseConfigured } from './supabaseClient';
import type { Session, User } from '@supabase/supabase-js';

interface AuthState {
  session: Session | null;
  user: User | null;
  loading: boolean;
  isDemo: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (name: string, email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  demoSignIn: () => void;
}

const AuthContext = createContext<AuthState | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [demoUser, setDemoUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!supabase) {
      setLoading(false);
      return;
    }
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (mounted) {
        setSession(data.session);
        setLoading(false);
      }
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess) => {
      if (mounted) setSession(sess);
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  async function signIn(email: string, password: string) {
    if (!supabase) return { error: 'Auth is not configured.' };
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  }

  async function signUp(name: string, email: string, password: string) {
    if (!supabase) return { error: 'Auth is not configured.' };
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: name } },
    });
    if (error) return { error: error.message };
    if (data.user) return { error: null };
    return { error: null };
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setSession(null);
    setDemoUser(null);
  }

  function demoSignIn() {
    const fakeUser = {
      id: 'demo-user',
      aud: 'authenticated',
      role: 'authenticated',
      email: 'demo@agripulse.ai',
      app_metadata: {},
      user_metadata: { full_name: 'Demo Farmer' },
      identities: [],
      created_at: new Date().toISOString(),
    } as unknown as User;
    setDemoUser(fakeUser);
  }

  const isDemo = Boolean(demoUser);
  const user = session?.user ?? demoUser;

  return (
    <AuthContext.Provider
      value={{ session, user, loading, isDemo, signIn, signUp, signOut, demoSignIn }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

export const authEnabled = isSupabaseConfigured;
