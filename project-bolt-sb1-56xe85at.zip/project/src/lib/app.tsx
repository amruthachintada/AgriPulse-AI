import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Language } from '@/types';
import { t as translate } from './translations';

interface AppCtx {
  lang: Language;
  setLang: (l: Language) => void;
  t: (key: string) => string;
  location: string;
  setLocation: (l: string) => void;
}

const Ctx = createContext<AppCtx | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Language>(() => (localStorage.getItem('ap-lang') as Language) || 'en');
  const [location, setLocation] = useState<string>(() => localStorage.getItem('ap-loc') || 'Vijayawada, Andhra Pradesh');

  useEffect(() => {
    localStorage.setItem('ap-lang', lang);
  }, [lang]);
  useEffect(() => {
    localStorage.setItem('ap-loc', location);
  }, [location]);

  return (
    <Ctx.Provider
      value={{
        lang,
        setLang,
        t: (k) => translate(lang, k),
        location,
        setLocation,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useApp() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
