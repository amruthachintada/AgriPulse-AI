/*
# AgriPulse AI — core schema

1. New Tables
- `fields` — a farmer's named field (name, location, crop, area, crop_age, irrigation, health, user_id)
- `crop_analyses` — saved AI crop analysis results (crop, image_url, diagnosis, confidence, severity, result JSON, user_id)
- `advisories` — advisory messages (title, category, severity, explanation, action, user_id)
2. Security
- Enable RLS on all tables.
- Owner-scoped CRUD via auth.uid() = user_id on all three tables.
- Owner columns default to auth.uid() so inserts omitting user_id succeed.
3. Notes
- Multi-user app with sign-in screen; policies scoped TO authenticated.
*/

CREATE TABLE IF NOT EXISTS fields (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  location text NOT NULL DEFAULT '',
  crop text NOT NULL,
  area text NOT NULL DEFAULT '',
  crop_age text NOT NULL DEFAULT '',
  irrigation text NOT NULL DEFAULT '',
  health integer NOT NULL DEFAULT 80,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE fields ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_fields" ON fields;
CREATE POLICY "select_own_fields" ON fields FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_fields" ON fields;
CREATE POLICY "insert_own_fields" ON fields FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_fields" ON fields;
CREATE POLICY "update_own_fields" ON fields FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_fields" ON fields;
CREATE POLICY "delete_own_fields" ON fields FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_fields_user ON fields(user_id);

CREATE TABLE IF NOT EXISTS crop_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crop text NOT NULL,
  image_url text NOT NULL DEFAULT '',
  diagnosis text NOT NULL,
  confidence integer NOT NULL DEFAULT 0,
  severity text NOT NULL DEFAULT 'Low',
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE crop_analyses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_analyses" ON crop_analyses;
CREATE POLICY "select_own_analyses" ON crop_analyses FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_analyses" ON crop_analyses;
CREATE POLICY "insert_own_analyses" ON crop_analyses FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_analyses" ON crop_analyses;
CREATE POLICY "update_own_analyses" ON crop_analyses FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_analyses" ON crop_analyses;
CREATE POLICY "delete_own_analyses" ON crop_analyses FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_analyses_user ON crop_analyses(user_id);

CREATE TABLE IF NOT EXISTS advisories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  category text NOT NULL,
  severity text NOT NULL DEFAULT 'Low',
  explanation text NOT NULL DEFAULT '',
  action text NOT NULL DEFAULT '',
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE advisories ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_advisories" ON advisories;
CREATE POLICY "select_own_advisories" ON advisories FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_advisories" ON advisories;
CREATE POLICY "insert_own_advisories" ON advisories FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_advisories" ON advisories;
CREATE POLICY "update_own_advisories" ON advisories FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_advisories" ON advisories;
CREATE POLICY "delete_own_advisories" ON advisories FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_advisories_user ON advisories(user_id);
